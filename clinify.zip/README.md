<div align="center">

<img src="public/favicon.svg" width="72" alt="Logo do Clinify" />

# CLINIFY

**A prática que transforma o aprendizado**

Simulador de casos clínicos para estudantes de Medicina, com avaliação instantânea do raciocínio clínico e do prontuário.

**Grupo Dev.Ak** · Challenge 1ESSPR-2026

🔗 **Deploy na Vercel:** https://SEU-PROJETO.vercel.app
📁 **Repositório no GitHub:** https://github.com/SEU_USUARIO/clinify

</div>

---

## 📌 Sumário

- [Sobre o projeto](#-sobre-o-projeto)
- [Funcionalidades](#-funcionalidades)
- [Telas responsivas](#-telas-responsivas)
- [Tecnologias utilizadas](#-tecnologias-utilizadas)
- [Como instalar e executar](#-como-instalar-e-executar)
- [Conta de teste](#-conta-de-teste)
- [Deploy na Vercel](#-deploy-na-vercel)
- [Estrutura de pastas](#-estrutura-de-pastas)
- [Como a avaliação funciona](#-como-a-avaliação-do-caso-funciona)
- [Uso de Inteligência Artificial](#-uso-de-inteligência-artificial)
- [Limitações e próximos passos](#-limitações-e-próximos-passos)
- [Integrantes](#-integrantes)

---

## 🩺 Sobre o projeto

### O problema

A transição da teoria para a decisão clínica gera **ansiedade** e o **receio de cometer erros na frente do paciente**. Na pesquisa feita pelo grupo com estudantes, a distância entre **teoria e prática** foi a dificuldade mais citada (100% das marcações), seguida de **medo de errar**, **tempo de aula** e **dificuldade do conteúdo** (75% cada).

Esse problema tem impacto real na saúde: segundo reportagem da CNN Brasil (17/09/2024), **falhas no diagnóstico respondem por 16% dos danos graves a pacientes**, e a maioria desses casos poderia ser evitada.

### A solução

O **Clinify** é um app de estudos que leva o aluno a praticar a tomada de decisão clínica de forma inovadora, mas com uma abordagem que ele já conhece: um **caso clínico** com história, sinais vitais e exame físico, no qual o aluno precisa escolher o diagnóstico, os exames e a conduta e **preencher o prontuário**.

A solução se apoia em três pilares:

| Pilar | O que significa no app |
|-------|------------------------|
| 🛡️ **Ambiente clínico seguro** | O aluno pode errar, testar hipóteses diagnósticas e aperfeiçoar condutas sem qualquer risco a pacientes reais. |
| 📈 **Autopercepção e caminho** | Avaliação **instantânea** do raciocínio clínico e do prontuário, mostrando onde o aluno precisa melhorar. |
| 📱 **Estudo adaptado à rotina** | Interface leve e **responsiva** para revisar casos e praticar pelo celular, em qualquer intervalo. |

---

## ✨ Funcionalidades

| Tela | Rota | O que faz |
|------|------|-----------|
| **Página inicial** | `/` | Apresenta o problema (dados da pesquisa com alunos), a solução e como o app funciona. |
| **Login / Cadastro** | `/login` | Entrar com uma conta existente ou criar uma nova. Mostra os dados da conta de teste. |
| **Início (painel)** | `/app` | Dias consecutivos de estudo, nível (XP), meta diária, taxa de acerto, **Desafio Diário** e casos recomendados. |
| **Simulação clínica** | `/app/simulacoes` | Lista de casos com filtro por especialidade e busca. Mostra a melhor nota de cada caso. |
| **Caso clínico** | `/app/simulacoes/:id` | Simulação em 5 etapas: **caso → hipótese diagnóstica → exames → conduta → prontuário**, com **feedback detalhado** no final. |
| **Estudos** | `/app/estudos` | Flashcards que viram ao clicar, com filtro por especialidade e opção de embaralhar. |
| **Desempenho** | `/app/desempenho` | Média por especialidade, gráfico de atividades dos últimos 14 dias, histórico de simulações e indicação de **onde melhorar**. |
| **Meu perfil** | `/app/perfil` | Editar dados, escolher a meta diária e zerar o progresso. |
| **Página 404** | qualquer outra | Página de "não encontrado". |

**Outros detalhes:**
- As rotas da área do aluno são **protegidas**: quem não está logado é levado para o login.
- O progresso fica **salvo por usuário** e continua lá mesmo depois de fechar o navegador.
- 5 casos clínicos fictícios: **Cardiologia, Pneumologia, Pediatria, Endocrinologia e Neurologia**.
- O caso de Pediatria inclui a **conferência da dose pelo peso**, relacionando o app à segurança do paciente.
- Menu lateral recolhível no computador e menu deslizante no celular.

---

## 📱 Telas responsivas

### Computador

| Página inicial | Login |
|:-:|:-:|
| ![Página inicial](docs/telas/landing_desktop_topo.jpg) | ![Login](docs/telas/login_desktop.jpg) |
| **Painel do aluno** | **Lista de casos** |
| ![Início](docs/telas/inicio_desktop.jpg) | ![Simulações](docs/telas/simulacoes_desktop.jpg) |
| **Caso clínico** | **Estudos (flashcard)** |
| ![Caso clínico](docs/telas/caso_desktop.jpg) | ![Estudos](docs/telas/estudos_desktop.jpg) |
| **Desempenho** | **Feedback da simulação** |
| ![Desempenho](docs/telas/desempenho_desktop.jpg) | ![Feedback](docs/telas/feedback_desktop.jpg) |

### Celular

| Página inicial | Login | Painel | Menu |
|:-:|:-:|:-:|:-:|
| ![](docs/telas/landing_celular_topo.jpg) | ![](docs/telas/login_celular.jpg) | ![](docs/telas/inicio_celular.jpg) | ![](docs/telas/menu_celular.jpg) |
| **Caso clínico** | **Flashcard** | | |
| ![](docs/telas/caso_celular.jpg) | ![](docs/telas/estudos_celular.jpg) | | |

> Protótipo / apresentação do grupo (Canva): *cole aqui o link de visualização da apresentação*

---

## 🛠️ Tecnologias utilizadas

| Tecnologia | Para quê |
|------------|----------|
| [React 19](https://react.dev/) | Biblioteca para construir a interface em componentes |
| [TypeScript](https://www.typescriptlang.org/) | JavaScript com tipos, para evitar erros nos dados dos casos e do progresso |
| [Vite](https://vite.dev/) | Ferramenta de build e servidor de desenvolvimento |
| [Tailwind CSS 4](https://tailwindcss.com/) | Estilização com classes utilitárias e tema próprio (`@theme`) |
| [React Router](https://reactrouter.com/) | Navegação entre páginas e rotas protegidas |
| [Lucide React](https://lucide.dev/) | Ícones |
| Context API + localStorage | Login e progresso do aluno salvos no navegador |
| [Vercel](https://vercel.com/) | Hospedagem e deploy |
| Git e GitHub | Versionamento do código |

---

## ▶️ Como instalar e executar

### Pré-requisitos

- [Node.js](https://nodejs.org/) **versão 20 ou superior** (o npm já vem junto)
- [Git](https://git-scm.com/)

Para conferir se estão instalados:

```bash
node -v
npm -v
git --version
```

### Passo a passo

```bash
# 1. Clonar o repositório
git clone https://github.com/SEU_USUARIO/clinify.git

# 2. Entrar na pasta
cd clinify

# 3. Instalar as dependências
npm install

# 4. Rodar em modo de desenvolvimento
npm run dev
```

Depois, abra no navegador o endereço que aparecer no terminal (normalmente **http://localhost:5173**).

### Outros comandos

| Comando | O que faz |
|---------|-----------|
| `npm run dev` | Roda o projeto em modo de desenvolvimento |
| `npm run build` | Gera a versão de produção na pasta `dist/` |
| `npm run preview` | Abre a versão de produção localmente |
| `npm run lint` | Verifica problemas no código |

---

## 🔑 Conta de teste

| E-mail | Senha |
|--------|-------|
| `aluno@clinify.com` | `clinify123` |

A conta de teste já vem com um **histórico de exemplo** (simulações e dias de estudo) para o painel e o desempenho não aparecerem vazios. Na tela de login também há o botão **"Preencher automaticamente"**.

Também é possível **criar uma conta nova** na aba "Criar conta". Ela começa com o progresso zerado.

---

## 🚀 Deploy na Vercel

1. Suba o projeto para um repositório no GitHub.
2. Acesse [vercel.com](https://vercel.com/) e entre com a conta do GitHub.
3. Clique em **Add New → Project** e escolha o repositório `clinify`.
4. A Vercel detecta o Vite sozinha. Confira:
   - **Framework Preset:** Vite
   - **Build Command:** `npm run build`
   - **Output Directory:** `dist`
5. Clique em **Deploy** e aguarde.

O arquivo `vercel.json` redireciona todas as rotas para o `index.html`. Sem ele, ao atualizar a página em `/app/estudos`, por exemplo, a Vercel mostraria erro 404.

A cada `git push` na branch `main`, a Vercel faz o deploy de novo automaticamente.

---

## 📁 Estrutura de pastas

```
clinify/
├── docs/telas/              → prints das telas usados neste README
├── public/
│   └── favicon.svg          → logo do Clinify
├── src/
│   ├── components/          → peças reutilizáveis (Logo, cartões, selos, rota protegida)
│   ├── context/
│   │   ├── AuthContext.tsx       → login, cadastro e sessão
│   │   └── ProgressoContext.tsx  → progresso e indicadores do aluno
│   ├── data/
│   │   ├── casos.ts         → os 5 casos clínicos fictícios
│   │   └── estudos.ts       → flashcards e perguntas do Desafio Diário
│   ├── layouts/
│   │   └── LayoutAluno.tsx  → menu lateral, barra superior e rodapé da área do aluno
│   ├── lib/
│   │   ├── armazenamento.ts → funções de localStorage e datas
│   │   └── avaliacao.ts     → cálculo da nota da simulação
│   ├── pages/
│   │   ├── Landing.tsx      → página inicial pública
│   │   ├── Login.tsx        → login e cadastro
│   │   ├── NaoEncontrado.tsx→ página 404
│   │   └── app/             → páginas da área do aluno
│   ├── App.tsx              → rotas
│   ├── main.tsx             → ponto de entrada
│   └── index.css            → Tailwind e tema (cores do Clinify)
├── INTEGRANTES.TXT
├── vercel.json
└── package.json
```

---

## 🧮 Como a avaliação do caso funciona

Ao finalizar uma simulação, o aluno recebe uma nota de **0 a 100**, calculada em `src/lib/avaliacao.ts`:

| Etapa | Peso | Regra |
|-------|:----:|-------|
| Hipótese diagnóstica | 40 | Acertou o diagnóstico = 40 pontos |
| Exames complementares | 25 | Cada exame correto marcado soma pontos e cada exame **desnecessário** desconta |
| Conduta inicial | 25 | Cada conduta correta soma pontos e cada conduta **inadequada** desconta |
| Prontuário | 10 | 5 pontos por escrever uma justificativa completa e 5 por usar os termos técnicos esperados do caso |

O desconto por itens errados existe para o aluno não "marcar tudo". Na prática clínica, pedir exames desnecessários ou fazer condutas inadequadas também tem custo e risco.

No feedback, **cada opção** mostra se o aluno acertou e **por quê**, e o caso termina com um **ponto-chave** para fixar o aprendizado.

---

## 🤖 Uso de Inteligência Artificial

Durante o desenvolvimento, o grupo usou o assistente de IA **Claude (Anthropic)**. A IA foi usada para criar a estrutura inicial do projeto em React + Vite + Tailwind, escrever os componentes e as páginas a partir da apresentação e do protótipo do grupo, sugerir a lógica de pontuação das simulações e do progresso do aluno, redigir os casos clínicos fictícios, os flashcards e as perguntas do Desafio Diário, e escrever esta documentação. A definição do problema, a pesquisa com os estudantes, a proposta de valor, a identidade visual e o protótipo das telas foram feitos pelo grupo, que também revisou, testou e ajustou o código e o conteúdo gerados. O conteúdo médico do app é **fictício e educacional** e deve ser validado por um professor da área antes de qualquer uso real.

---

## 🚧 Limitações e próximos passos

**Limitações atuais**
- Não há back-end: usuários e progresso ficam no `localStorage` do navegador. Trocar de navegador ou limpar os dados apaga o progresso.
- As senhas ficam salvas sem criptografia no navegador. Isso é aceitável só por ser um protótipo acadêmico.
- O conteúdo dos casos é fixo no código.

**Próximos passos**
- Back-end com banco de dados e autenticação real (ex.: Supabase ou Firebase).
- Painel para professores cadastrarem e revisarem casos.
- Correção do prontuário com IA, dando feedback sobre o texto livre do aluno.
- Ranking da turma e mais especialidades.

---

## 👥 Integrantes

Os nomes completos e os RMs estão no arquivo [`INTEGRANTES.TXT`](INTEGRANTES.TXT).

<div align="center">

Feito com 💙 pelo **Grupo Dev.Ak**

</div>
