// =========================================================
// Casos clínicos FICTÍCIOS usados nas simulações.
// Conteúdo com finalidade educacional, não substitui protocolos oficiais.
// =========================================================

export type Dificuldade = "Fácil" | "Médio" | "Difícil";

export interface Opcao {
  id: string;
  texto: string;
  correta: boolean;
  motivo: string; // explicação mostrada no feedback
}

export interface CasoClinico {
  id: string;
  titulo: string;
  especialidade: string;
  dificuldade: Dificuldade;
  tempoMin: number;
  resumo: string;
  paciente: { nome: string; idade: number; sexo: "Masculino" | "Feminino" };
  queixaPrincipal: string;
  historia: string;
  antecedentes: string;
  sinaisVitais: { pa: string; fc: string; fr: string; temp: string; sat: string };
  exameFisico: string;
  diagnosticos: Opcao[]; // só uma é correta
  exames: Opcao[]; // várias corretas
  condutas: Opcao[]; // várias corretas
  palavrasChave: string[]; // termos esperados na justificativa do prontuário
  explicacaoFinal: string;
}

export const casos: CasoClinico[] = [
  {
    id: "dor-toracica",
    titulo: "Dor torácica no pronto-socorro",
    especialidade: "Cardiologia",
    dificuldade: "Médio",
    tempoMin: 10,
    resumo: "Homem de 58 anos com dor no peito em aperto há 40 minutos.",
    paciente: { nome: "J. R. S.", idade: 58, sexo: "Masculino" },
    queixaPrincipal: "Dor no peito há 40 minutos.",
    historia:
      "Paciente relata dor retroesternal em aperto, de forte intensidade, iniciada em repouso há cerca de 40 minutos, com irradiação para o membro superior esquerdo e mandíbula. Refere sudorese fria e náusea. Nega trauma.",
    antecedentes: "Hipertensão arterial, tabagista (30 anos-maço), dislipidemia. Pai faleceu de infarto aos 60 anos.",
    sinaisVitais: { pa: "150 x 90 mmHg", fc: "98 bpm", fr: "20 irpm", temp: "36,4 °C", sat: "96%" },
    exameFisico: "Ansioso, sudoreico. Ausculta cardíaca com ritmo regular, sem sopros. Pulmões limpos. Pulsos simétricos nos quatro membros.",
    diagnosticos: [
      { id: "a", texto: "Síndrome coronariana aguda (infarto agudo do miocárdio)", correta: true, motivo: "Dor típica em aperto, em repouso, com irradiação, sudorese e vários fatores de risco cardiovascular." },
      { id: "b", texto: "Dissecção aguda de aorta", correta: false, motivo: "Importante lembrar, mas a dor costuma ser lacerante, irradiando para o dorso, e os pulsos são assimétricos. Aqui os pulsos estão simétricos." },
      { id: "c", texto: "Pericardite aguda", correta: false, motivo: "A dor da pericardite costuma ser pleurítica e melhorar ao inclinar o tronco para frente, geralmente com atrito pericárdico." },
      { id: "d", texto: "Doença do refluxo gastroesofágico", correta: false, motivo: "Não explica a sudorese, a irradiação e o quadro em paciente de alto risco. Causas graves devem ser descartadas primeiro." },
    ],
    exames: [
      { id: "ecg", texto: "Eletrocardiograma em até 10 minutos", correta: true, motivo: "É o exame mais importante e deve ser feito em até 10 minutos da chegada." },
      { id: "trop", texto: "Troponina (marcador de necrose miocárdica)", correta: true, motivo: "Confirma lesão do miocárdio e ajuda na classificação do quadro." },
      { id: "rx", texto: "Radiografia de tórax", correta: true, motivo: "Ajuda a avaliar diagnósticos diferenciais e congestão, sem atrasar o ECG." },
      { id: "eda", texto: "Endoscopia digestiva alta", correta: false, motivo: "Não está indicada na suspeita de síndrome coronariana e atrasaria o tratamento." },
      { id: "tcc", texto: "Tomografia de crânio", correta: false, motivo: "Não há sintomas neurológicos que justifiquem o exame." },
    ],
    condutas: [
      { id: "mon", texto: "Monitorização cardíaca contínua e acesso venoso", correta: true, motivo: "Permite detectar arritmias e administrar medicações rapidamente." },
      { id: "aas", texto: "Administrar antiagregante plaquetário (AAS), se não houver contraindicação", correta: true, motivo: "Reduz a mortalidade na síndrome coronariana aguda." },
      { id: "rep", texto: "Acionar a equipe para terapia de reperfusão, se o ECG confirmar supradesnivelamento de ST", correta: true, motivo: "Tempo é músculo: quanto antes a artéria for aberta, menor o dano ao coração." },
      { id: "o2", texto: "Oxigênio de rotina, mesmo com saturação normal", correta: false, motivo: "Oxigênio só é indicado com saturação abaixo de 90%. Aqui a saturação é de 96%." },
      { id: "alta", texto: "Dar alta com analgésico e orientar retorno se piorar", correta: false, motivo: "Conduta perigosa: o paciente tem alto risco de infarto e precisa de investigação imediata." },
    ],
    palavrasChave: ["ecg", "troponina", "infarto", "coronariana", "aas", "risco"],
    explicacaoFinal:
      "Na dor torácica, o primeiro passo é sempre descartar causas que ameaçam a vida. O ECG em até 10 minutos define o caminho: se houver supradesnivelamento de ST, a reperfusão deve ser feita o quanto antes.",
  },
  {
    id: "pneumonia",
    titulo: "Febre e tosse em idosa",
    especialidade: "Pneumologia",
    dificuldade: "Fácil",
    tempoMin: 8,
    resumo: "Mulher de 67 anos com febre, tosse produtiva e falta de ar há 4 dias.",
    paciente: { nome: "M. L. A.", idade: 67, sexo: "Feminino" },
    queixaPrincipal: "Febre e tosse com catarro há 4 dias.",
    historia:
      "Iniciou há 4 dias com febre de até 38,8 °C, tosse com expectoração amarelada e dor ao respirar no lado direito do tórax. Há 1 dia refere cansaço aos pequenos esforços. Está orientada.",
    antecedentes: "Diabetes tipo 2 controlado com metformina. Nega internações recentes ou uso de antibiótico nos últimos 3 meses.",
    sinaisVitais: { pa: "128 x 78 mmHg", fc: "104 bpm", fr: "24 irpm", temp: "38,5 °C", sat: "92%" },
    exameFisico: "Corada, levemente desidratada. Estertores crepitantes em base pulmonar direita, com aumento do frêmito toracovocal no mesmo local.",
    diagnosticos: [
      { id: "a", texto: "Pneumonia adquirida na comunidade", correta: true, motivo: "Febre, tosse produtiva, dor pleurítica e crepitações localizadas formam o quadro clássico." },
      { id: "b", texto: "Insuficiência cardíaca descompensada", correta: false, motivo: "Causaria crepitações bilaterais, edema e sem febre. Aqui o achado é localizado e com febre." },
      { id: "c", texto: "Crise de asma", correta: false, motivo: "A asma causa sibilos difusos, não crepitações localizadas com febre." },
      { id: "d", texto: "Resfriado comum", correta: false, motivo: "Não explica a taquipneia, a saturação baixa e os achados pulmonares." },
    ],
    exames: [
      { id: "rx", texto: "Radiografia de tórax", correta: true, motivo: "Confirma a consolidação e avalia a extensão." },
      { id: "hemo", texto: "Hemograma", correta: true, motivo: "Avalia leucocitose e ajuda na gravidade." },
      { id: "ureia", texto: "Ureia e creatinina", correta: true, motivo: "A ureia faz parte do escore CURB-65, usado para decidir o local de tratamento." },
      { id: "rm", texto: "Ressonância magnética de tórax", correta: false, motivo: "Não faz parte da investigação inicial e é cara e demorada." },
      { id: "eco", texto: "Ecocardiograma de rotina", correta: false, motivo: "Não há sinais de doença cardíaca que justifiquem o exame agora." },
    ],
    condutas: [
      { id: "curb", texto: "Calcular o escore de gravidade (CURB-65) para decidir o local do tratamento", correta: true, motivo: "Idade ≥ 65 anos já pontua: o escore ajuda a decidir entre tratamento em casa ou internação." },
      { id: "atb", texto: "Iniciar antibiótico empírico o mais cedo possível", correta: true, motivo: "O antibiótico precoce reduz complicações na pneumonia bacteriana." },
      { id: "o2", texto: "Oferecer oxigênio para manter saturação adequada", correta: true, motivo: "A saturação de 92% com taquipneia indica necessidade de suporte." },
      { id: "anti", texto: "Apenas antitérmico e alta, sem antibiótico", correta: false, motivo: "A pneumonia bacteriana precisa de antibiótico, ainda mais em idosa com diabetes." },
      { id: "cort", texto: "Corticoide de rotina para todos os casos", correta: false, motivo: "Não é indicado de rotina na pneumonia comunitária sem outras indicações." },
    ],
    palavrasChave: ["pneumonia", "radiografia", "antibiotico", "curb", "saturacao", "febre"],
    explicacaoFinal:
      "Na pneumonia comunitária, além de confirmar o diagnóstico, é essencial avaliar a gravidade (ex.: CURB-65). Isso define se a paciente pode tratar em casa ou se precisa ser internada.",
  },
  {
    id: "asma-pediatrica",
    titulo: "Criança com falta de ar",
    especialidade: "Pediatria",
    dificuldade: "Médio",
    tempoMin: 10,
    resumo: "Menino de 7 anos, com asma, chega com chiado e esforço para respirar.",
    paciente: { nome: "P. H. C.", idade: 7, sexo: "Masculino" },
    queixaPrincipal: "Chiado no peito e falta de ar desde a madrugada.",
    historia:
      "Mãe relata que a criança está resfriada há 2 dias e, desde a madrugada, apresenta chiado no peito, tosse seca e dificuldade para falar frases completas. Usou o broncodilatador de casa 2 vezes, sem melhora.",
    antecedentes: "Asma diagnosticada aos 4 anos. Peso: 24 kg. Sem alergia a medicamentos.",
    sinaisVitais: { pa: "100 x 60 mmHg", fc: "130 bpm", fr: "36 irpm", temp: "37,2 °C", sat: "91%" },
    exameFisico: "Agitado, fala frases curtas. Tiragem subcostal e intercostal. Sibilos difusos à ausculta, com murmúrio vesicular diminuído nas bases.",
    diagnosticos: [
      { id: "a", texto: "Crise de asma moderada a grave", correta: true, motivo: "Criança asmática com sibilos difusos, tiragem, dificuldade para falar e saturação de 91%." },
      { id: "b", texto: "Pneumonia bacteriana", correta: false, motivo: "Não há febre alta nem achado localizado. O quadro é de broncoespasmo difuso." },
      { id: "c", texto: "Aspiração de corpo estranho", correta: false, motivo: "Costuma ter início súbito com engasgo e achados unilaterais, o que não ocorre aqui." },
      { id: "d", texto: "Laringite viral", correta: false, motivo: "A laringite causa estridor e tosse ladrante, não sibilos difusos." },
    ],
    exames: [
      { id: "oxi", texto: "Oximetria de pulso contínua", correta: true, motivo: "Acompanha a resposta ao tratamento de forma simples e rápida." },
      { id: "escore", texto: "Reavaliação clínica seriada (esforço, fala, frequência respiratória)", correta: true, motivo: "Na crise de asma, a avaliação clínica repetida é mais importante do que exames de imagem." },
      { id: "rx", texto: "Radiografia de tórax obrigatória antes de tratar", correta: false, motivo: "Não é rotina na crise de asma e não deve atrasar o tratamento." },
      { id: "tc", texto: "Tomografia de tórax", correta: false, motivo: "Expõe a criança à radiação sem mudar a conduta." },
    ],
    condutas: [
      { id: "bd", texto: "Broncodilatador inalatório de curta ação, repetido nas primeiras horas", correta: true, motivo: "É o tratamento principal para reverter o broncoespasmo." },
      { id: "cort", texto: "Corticoide sistêmico precoce", correta: true, motivo: "Reduz a inflamação e a chance de internação." },
      { id: "o2", texto: "Oxigênio para manter a saturação adequada", correta: true, motivo: "A saturação de 91% indica hipoxemia." },
      { id: "dose", texto: "Conferir a dose de cada medicamento pelo peso da criança (24 kg) antes de prescrever", correta: true, motivo: "Em pediatria as doses dependem do peso. Erros de prescrição são uma das principais causas de eventos graves." },
      { id: "atb", texto: "Antibiótico de rotina", correta: false, motivo: "Não há sinais de infecção bacteriana. O gatilho mais provável é viral." },
      { id: "sed", texto: "Sedativo para acalmar a criança", correta: false, motivo: "Perigoso: pode deprimir a respiração. A agitação aqui é sinal de hipoxemia." },
    ],
    palavrasChave: ["asma", "broncodilatador", "corticoide", "peso", "dose", "saturacao"],
    explicacaoFinal:
      "Na crise de asma pediátrica, tratar rápido é fundamental. E a segurança na prescrição faz parte do tratamento: em criança, toda dose deve ser calculada pelo peso e conferida antes de ser administrada.",
  },
  {
    id: "cetoacidose",
    titulo: "Jovem com vômitos e respiração rápida",
    especialidade: "Endocrinologia",
    dificuldade: "Difícil",
    tempoMin: 12,
    resumo: "Jovem de 19 anos com diabetes tipo 1, vômitos e dor abdominal.",
    paciente: { nome: "L. F. M.", idade: 19, sexo: "Feminino" },
    queixaPrincipal: "Vômitos e dor na barriga desde ontem.",
    historia:
      "Paciente com diabetes tipo 1 relata que parou de usar insulina há 3 dias por falta do medicamento. Desde então refere muita sede, urina em grande quantidade, vômitos e dor abdominal difusa. Familiar percebeu respiração rápida e profunda.",
    antecedentes: "Diabetes tipo 1 desde os 12 anos, em uso de insulina basal e rápida.",
    sinaisVitais: { pa: "100 x 60 mmHg", fc: "118 bpm", fr: "30 irpm (profunda)", temp: "36,8 °C", sat: "98%" },
    exameFisico: "Desidratada, mucosas secas, hálito cetônico (cheiro de fruta). Respiração de Kussmaul. Abdome doloroso difusamente, sem sinais de peritonite. Glicemia capilar: 480 mg/dL.",
    diagnosticos: [
      { id: "a", texto: "Cetoacidose diabética", correta: true, motivo: "Diabetes tipo 1 sem insulina, hiperglicemia, desidratação, hálito cetônico e respiração de Kussmaul." },
      { id: "b", texto: "Apendicite aguda", correta: false, motivo: "A dor abdominal da cetoacidose é comum e difusa. Aqui ela é explicada pelo quadro metabólico." },
      { id: "c", texto: "Hipoglicemia", correta: false, motivo: "A glicemia capilar está em 480 mg/dL, ou seja, muito alta." },
      { id: "d", texto: "Gastroenterite viral", correta: false, motivo: "Não explica a hiperglicemia grave, a respiração de Kussmaul e o hálito cetônico." },
    ],
    exames: [
      { id: "gaso", texto: "Gasometria (avaliar acidose)", correta: true, motivo: "Confirma a acidose metabólica e mostra a gravidade." },
      { id: "ceto", texto: "Dosagem de cetonas no sangue ou na urina", correta: true, motivo: "Confirma a presença de cetose." },
      { id: "elet", texto: "Eletrólitos, principalmente potássio", correta: true, motivo: "O potássio precisa ser conhecido antes de iniciar a insulina, porque ela faz o potássio cair." },
      { id: "endo", texto: "Endoscopia digestiva", correta: false, motivo: "Não ajuda no diagnóstico e atrasaria o tratamento." },
    ],
    condutas: [
      { id: "hidra", texto: "Hidratação venosa vigorosa", correta: true, motivo: "É o primeiro passo: corrige a desidratação e já reduz a glicemia." },
      { id: "ins", texto: "Insulina venosa após conhecer o valor do potássio", correta: true, motivo: "A insulina resolve a cetose, mas iniciar com potássio baixo pode causar arritmias." },
      { id: "pot", texto: "Repor potássio de acordo com o resultado do exame", correta: true, motivo: "A reposição de potássio evita complicações graves durante o tratamento." },
      { id: "bic", texto: "Bicarbonato de rotina para todos os pacientes", correta: false, motivo: "Só é indicado em casos muito específicos de acidose extrema." },
      { id: "oral", texto: "Hidratação oral e alta com orientação", correta: false, motivo: "A cetoacidose é uma emergência e exige tratamento hospitalar." },
    ],
    palavrasChave: ["cetoacidose", "hidratacao", "insulina", "potassio", "gasometria", "glicemia"],
    explicacaoFinal:
      "O tratamento da cetoacidose tem uma ordem: hidratar, checar o potássio e só então iniciar a insulina. Pular etapas pode causar complicações graves.",
  },
  {
    id: "avc",
    titulo: "Fraqueza súbita em um lado do corpo",
    especialidade: "Neurologia",
    dificuldade: "Difícil",
    tempoMin: 10,
    resumo: "Mulher de 72 anos com perda de força no lado direito e dificuldade para falar.",
    paciente: { nome: "A. C. P.", idade: 72, sexo: "Feminino" },
    queixaPrincipal: "Perda de força no braço e perna direitos há 1 hora.",
    historia:
      "Filha relata que a paciente estava bem no café da manhã e, há 1 hora, de forma súbita, apresentou perda de força no braço e na perna direitos, boca torta e dificuldade para falar. Horário de início bem definido.",
    antecedentes: "Hipertensão, fibrilação atrial sem uso regular de anticoagulante.",
    sinaisVitais: { pa: "170 x 95 mmHg", fc: "92 bpm (irregular)", fr: "18 irpm", temp: "36,5 °C", sat: "97%" },
    exameFisico: "Desvio de rima labial para a esquerda, hemiparesia direita (força grau 2) e afasia de expressão. Ritmo cardíaco irregular.",
    diagnosticos: [
      { id: "a", texto: "Acidente vascular cerebral (AVC) agudo", correta: true, motivo: "Déficit neurológico súbito e focal em paciente com fibrilação atrial sem anticoagulação." },
      { id: "b", texto: "Enxaqueca com aura", correta: false, motivo: "Ocorre em pessoas mais jovens, com cefaleia e sintomas que se instalam de forma gradual." },
      { id: "c", texto: "Crise convulsiva", correta: false, motivo: "Não há relato de crise. A fraqueza pós-crise é possível, mas o quadro é típico de AVC." },
      { id: "d", texto: "Labirintite", correta: false, motivo: "Causa tontura e vertigem, não perda de força de um lado do corpo." },
    ],
    exames: [
      { id: "glic", texto: "Glicemia capilar imediata", correta: true, motivo: "A hipoglicemia pode imitar um AVC e é corrigida rapidamente." },
      { id: "tc", texto: "Tomografia de crânio sem contraste com urgência", correta: true, motivo: "Diferencia AVC isquêmico de hemorrágico, o que muda totalmente o tratamento." },
      { id: "ecg", texto: "Eletrocardiograma", correta: true, motivo: "Confirma a fibrilação atrial, provável causa do AVC." },
      { id: "eeg", texto: "Eletroencefalograma antes da tomografia", correta: false, motivo: "Atrasaria a tomografia, que é o exame decisivo." },
    ],
    condutas: [
      { id: "prot", texto: "Acionar o protocolo de AVC e registrar o horário de início dos sintomas", correta: true, motivo: "O horário define se a paciente está dentro da janela para trombólise." },
      { id: "trombo", texto: "Avaliar trombólise se o AVC for isquêmico e estiver dentro da janela de tempo", correta: true, motivo: "Pode reverter o déficit se feita a tempo." },
      { id: "aas", texto: "Dar AAS antes da tomografia", correta: false, motivo: "Se o AVC for hemorrágico, o AAS pode piorar o sangramento." },
      { id: "pa", texto: "Baixar a pressão rapidamente para menos de 120 x 80 mmHg", correta: false, motivo: "Baixar a pressão de forma agressiva pode reduzir o fluxo para a área do cérebro em risco." },
      { id: "esperar", texto: "Aguardar algumas horas para ver se os sintomas melhoram", correta: false, motivo: "No AVC, tempo é cérebro: cada minuto de atraso significa perda de neurônios." },
    ],
    palavrasChave: ["avc", "tomografia", "glicemia", "horario", "tromb", "protocolo"],
    explicacaoFinal:
      "No AVC, o horário de início dos sintomas e a tomografia de crânio são as informações mais importantes. Elas definem se a paciente pode receber trombólise.",
  },
];

export function buscarCaso(id: string | undefined) {
  return casos.find((caso) => caso.id === id);
}
