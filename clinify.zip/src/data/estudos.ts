// Flashcards da área de Estudos e perguntas do Desafio Diário

export interface Flashcard {
  id: number;
  especialidade: string;
  pergunta: string;
  resposta: string;
}

export const flashcards: Flashcard[] = [
  { id: 1, especialidade: "Cardiologia", pergunta: "Em quanto tempo o ECG deve ser feito em um paciente com dor torácica?", resposta: "Em até 10 minutos após a chegada ao serviço de saúde." },
  { id: 2, especialidade: "Cardiologia", pergunta: "Quais são os fatores de risco cardiovascular clássicos?", resposta: "Hipertensão, diabetes, tabagismo, dislipidemia, obesidade, sedentarismo e história familiar." },
  { id: 3, especialidade: "Cardiologia", pergunta: "Quando o oxigênio é indicado na síndrome coronariana aguda?", resposta: "Quando a saturação está abaixo de 90%. Não é indicado de rotina." },
  { id: 4, especialidade: "Pneumologia", pergunta: "O que avalia o escore CURB-65?", resposta: "Confusão, Ureia elevada, frequência Respiratória ≥ 30, Pressão baixa (Blood pressure) e idade ≥ 65 anos." },
  { id: 5, especialidade: "Pneumologia", pergunta: "Qual o achado clássico de consolidação no exame físico?", resposta: "Estertores crepitantes localizados e aumento do frêmito toracovocal." },
  { id: 6, especialidade: "Pediatria", pergunta: "Por que as doses em pediatria são calculadas pelo peso?", resposta: "Porque o metabolismo e o volume corporal variam muito com a idade. A dose por peso evita sub e superdosagem." },
  { id: 7, especialidade: "Pediatria", pergunta: "Qual o tratamento principal da crise de asma?", resposta: "Broncodilatador inalatório de curta ação, associado a corticoide sistêmico nas crises moderadas e graves." },
  { id: 8, especialidade: "Endocrinologia", pergunta: "Qual exame deve ser conhecido antes de iniciar insulina na cetoacidose?", resposta: "O potássio, porque a insulina leva o potássio para dentro das células e pode causar hipocalemia." },
  { id: 9, especialidade: "Endocrinologia", pergunta: "O que é a respiração de Kussmaul?", resposta: "Respiração rápida e profunda, uma tentativa do corpo de eliminar CO₂ para compensar a acidose metabólica." },
  { id: 10, especialidade: "Neurologia", pergunta: "Por que o horário de início dos sintomas é tão importante no AVC?", resposta: "Porque define se o paciente está dentro da janela de tempo para trombólise." },
  { id: 11, especialidade: "Neurologia", pergunta: "Qual exame diferencia AVC isquêmico de hemorrágico?", resposta: "A tomografia de crânio sem contraste." },
  { id: 12, especialidade: "Segurança do paciente", pergunta: "O que são os \"certos\" da administração de medicamentos?", resposta: "Checar paciente certo, medicamento certo, dose certa, via certa e horário certo antes de administrar." },
];

export interface PerguntaDesafio {
  pergunta: string;
  opcoes: string[];
  correta: number; // índice da opção correta
  explicacao: string;
}

export const desafios: PerguntaDesafio[] = [
  { pergunta: "Paciente com dor torácica típica chega ao PS. Qual o primeiro exame?", opcoes: ["Troponina", "Eletrocardiograma", "Raio-x de tórax", "Ecocardiograma"], correta: 1, explicacao: "O ECG deve ser feito em até 10 minutos e define a conduta." },
  { pergunta: "Na cetoacidose diabética, o que deve ser checado antes da insulina?", opcoes: ["Sódio", "Cálcio", "Potássio", "Magnésio"], correta: 2, explicacao: "A insulina reduz o potássio no sangue e pode causar arritmias se ele já estiver baixo." },
  { pergunta: "Qual informação define a janela para trombólise no AVC?", opcoes: ["Idade", "Pressão arterial", "Horário de início dos sintomas", "Glicemia"], correta: 2, explicacao: "O tempo desde o início dos sintomas define se a trombólise pode ser feita." },
  { pergunta: "Qual destes itens NÃO faz parte do CURB-65?", opcoes: ["Confusão mental", "Ureia", "Temperatura", "Idade ≥ 65"], correta: 2, explicacao: "A temperatura não faz parte do escore." },
  { pergunta: "Criança de 20 kg precisa de um medicamento. O que é essencial antes de prescrever?", opcoes: ["Calcular e conferir a dose pelo peso", "Usar a dose de adulto pela metade", "Perguntar a dose para a família", "Usar a menor ampola disponível"], correta: 0, explicacao: "Em pediatria, toda dose deve ser calculada pelo peso e conferida." },
  { pergunta: "Na crise de asma, a agitação da criança pode indicar:", opcoes: ["Birra", "Hipoxemia", "Febre", "Fome"], correta: 1, explicacao: "Agitação em crise respiratória pode ser sinal de falta de oxigênio. Nunca sedar." },
  { pergunta: "Oxigênio na síndrome coronariana aguda é indicado quando:", opcoes: ["Sempre", "Saturação < 90%", "Dor intensa", "Pressão alta"], correta: 1, explicacao: "O oxigênio de rotina com saturação normal não traz benefício." },
];

/** Escolhe a pergunta do dia (muda todo dia, mas é a mesma para o dia inteiro). */
export function desafioDoDia(data = new Date()) {
  const inicioAno = new Date(data.getFullYear(), 0, 0);
  const diaDoAno = Math.floor((data.getTime() - inicioAno.getTime()) / 86400000);
  return desafios[diaDoAno % desafios.length];
}
