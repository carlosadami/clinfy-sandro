import { BrowserRouter, Route, Routes } from "react-router-dom";
import { RotaProtegida } from "./components/RotaProtegida";
import { AuthProvider } from "./context/AuthContext";
import { ProgressoProvider } from "./context/ProgressoContext";
import { LayoutAluno } from "./layouts/LayoutAluno";
import { Desempenho } from "./pages/app/Desempenho";
import { Estudos } from "./pages/app/Estudos";
import { Inicio } from "./pages/app/Inicio";
import { Perfil } from "./pages/app/Perfil";
import { Simulacao } from "./pages/app/Simulacao";
import { Simulacoes } from "./pages/app/Simulacoes";
import { Landing } from "./pages/Landing";
import { Login } from "./pages/Login";
import { NaoEncontrado } from "./pages/NaoEncontrado";

export default function App() {
  return (
    <AuthProvider>
      <ProgressoProvider>
        <BrowserRouter>
          <Routes>
            {/* páginas públicas */}
            <Route path="/" element={<Landing />} />
            <Route path="/login" element={<Login />} />

            {/* área do aluno (precisa estar logado) */}
            <Route element={<RotaProtegida />}>
              <Route path="/app" element={<LayoutAluno />}>
                <Route index element={<Inicio />} />
                <Route path="simulacoes" element={<Simulacoes />} />
                <Route path="simulacoes/:id" element={<Simulacao />} />
                <Route path="estudos" element={<Estudos />} />
                <Route path="desempenho" element={<Desempenho />} />
                <Route path="perfil" element={<Perfil />} />
              </Route>
            </Route>

            <Route path="*" element={<NaoEncontrado />} />
          </Routes>
        </BrowserRouter>
      </ProgressoProvider>
    </AuthProvider>
  );
}
