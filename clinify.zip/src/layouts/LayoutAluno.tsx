import { useState } from "react";
import type { FormEvent } from "react";
import { NavLink, Outlet, useLocation, useNavigate } from "react-router-dom";
import {
  Bell,
  BookOpen,
  ChartColumn,
  ChevronLeft,
  House,
  LogOut,
  Menu,
  Search,
  Stethoscope,
  User,
  X,
} from "lucide-react";
import { Logo } from "../components/Logo";
import { useAuth } from "../context/AuthContext";
import { useProgresso } from "../context/ProgressoContext";
import { iniciais } from "../lib/armazenamento";

const links = [
  { para: "/app", texto: "Início", icone: House, fim: true },
  { para: "/app/simulacoes", texto: "Simulação clínica", icone: Stethoscope },
  { para: "/app/estudos", texto: "Estudos", icone: BookOpen },
  { para: "/app/desempenho", texto: "Desempenho", icone: ChartColumn },
  { para: "/app/perfil", texto: "Meu perfil", icone: User },
];

/** Estrutura da área do aluno: menu lateral + barra superior + conteúdo + rodapé. */
export function LayoutAluno() {
  const { usuario, sair } = useAuth();
  const { indicadores } = useProgresso();
  const navegar = useNavigate();
  const local = useLocation();

  const [menuAberto, setMenuAberto] = useState(false); // menu no celular
  const [recolhido, setRecolhido] = useState(false); // menu recolhido no computador
  const [notificacoesAbertas, setNotificacoesAbertas] = useState(false);
  const [busca, setBusca] = useState("");

  // fecha o menu do celular sempre que muda de página
  const [paginaAtual, setPaginaAtual] = useState(local.pathname);
  if (paginaAtual !== local.pathname) {
    setPaginaAtual(local.pathname);
    setMenuAberto(false);
    setNotificacoesAbertas(false);
  }

  function pesquisar(evento: FormEvent) {
    evento.preventDefault();
    navegar(`/app/simulacoes?busca=${encodeURIComponent(busca)}`);
  }

  function voltarAoLogin() {
    sair();
    navegar("/login");
  }

  const notificacoes = [
    indicadores.sequencia > 0
      ? `Você está há ${indicadores.sequencia} dia(s) seguidos estudando. Continue assim!`
      : "Comece hoje a sua sequência de estudos.",
    indicadores.metaPercentual < 100
      ? `Faltam ${100 - indicadores.metaPercentual}% para bater a meta de hoje.`
      : "Meta diária concluída! 🎉",
    "Novo caso disponível: Fraqueza súbita em um lado do corpo (Neurologia).",
  ];

  const menuLateral = (
    <div className="flex h-full flex-col">
      <div className="flex items-center justify-between border-b border-slate-100 px-4 py-4">
        <div className={recolhido ? "lg:hidden" : ""}>
          <p className="text-[11px] font-medium text-slate-400">Hospital Moinhos de Vento</p>
          <Logo tamanho={30} />
        </div>
        {recolhido && (
          <span className="hidden lg:block">
            <Logo tamanho={30} comTexto={false} />
          </span>
        )}
        <button
          onClick={() => setMenuAberto(false)}
          className="rounded-lg p-1.5 text-slate-500 hover:bg-slate-100 lg:hidden"
          aria-label="Fechar menu"
        >
          <X className="size-5" />
        </button>
      </div>

      <nav className="flex-1 space-y-1 p-3" aria-label="Menu principal">
        {links.map(({ para, texto, icone: Icone, fim }) => (
          <NavLink
            key={para}
            to={para}
            end={fim}
            title={texto}
            className={({ isActive }) =>
              `flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition ${
                isActive
                  ? "bg-marinho-50 text-marinho-700 ring-1 ring-marinho-200"
                  : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
              } ${recolhido ? "lg:justify-center" : ""}`
            }
          >
            <Icone className="size-4.5 shrink-0" />
            <span className={recolhido ? "lg:hidden" : ""}>{texto}</span>
          </NavLink>
        ))}
      </nav>

      <div className="border-t border-slate-100 p-3">
        <button
          onClick={voltarAoLogin}
          className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-slate-600 hover:bg-rose-50 hover:text-rose-600 ${
            recolhido ? "lg:justify-center" : ""
          }`}
        >
          <LogOut className="size-4.5" />
          <span className={recolhido ? "lg:hidden" : ""}>Voltar ao login</span>
        </button>
      </div>
    </div>
  );

  return (
    <div className="flex min-h-screen">
      {/* ===== Menu lateral (computador) ===== */}
      <aside
        className={`sticky top-0 hidden h-screen shrink-0 border-r border-slate-200 bg-white transition-all lg:block ${
          recolhido ? "w-20" : "w-64"
        }`}
      >
        {menuLateral}
        <button
          onClick={() => setRecolhido(!recolhido)}
          className="absolute -right-3 top-7 flex size-6 items-center justify-center rounded-full border border-slate-200 bg-white text-slate-500 shadow-sm hover:text-marinho-700"
          aria-label={recolhido ? "Expandir menu" : "Recolher menu"}
        >
          <ChevronLeft className={`size-4 transition ${recolhido ? "rotate-180" : ""}`} />
        </button>
      </aside>

      {/* ===== Menu lateral (celular) ===== */}
      {menuAberto && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div className="absolute inset-0 bg-slate-900/40" onClick={() => setMenuAberto(false)} />
          <aside className="absolute inset-y-0 left-0 w-72 bg-white shadow-xl animate-aparecer">{menuLateral}</aside>
        </div>
      )}

      {/* ===== Conteúdo ===== */}
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-30 flex items-center gap-3 border-b border-slate-200 bg-white/90 px-4 py-3 backdrop-blur sm:px-6">
          <button
            onClick={() => setMenuAberto(true)}
            className="rounded-lg p-2 text-slate-600 hover:bg-slate-100 lg:hidden"
            aria-label="Abrir menu"
          >
            <Menu className="size-5" />
          </button>

          <form onSubmit={pesquisar} className="relative max-w-md flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-slate-400" />
            <input
              value={busca}
              onChange={(e) => setBusca(e.target.value)}
              placeholder="Buscar casos clínicos..."
              className="w-full rounded-xl border border-slate-200 bg-slate-50 py-2 pl-9 pr-3 text-sm outline-none transition focus:border-marinho-500 focus:bg-white focus:ring-4 focus:ring-marinho-100"
            />
          </form>

          <div className="ml-auto flex items-center gap-2">
            <div className="relative">
              <button
                onClick={() => setNotificacoesAbertas(!notificacoesAbertas)}
                className="relative rounded-lg p-2 text-slate-600 hover:bg-slate-100"
                aria-label="Notificações"
              >
                <Bell className="size-5" />
                <span className="absolute right-1.5 top-1.5 size-2 rounded-full bg-roxo-500" />
              </button>
              {notificacoesAbertas && (
                <div className="cartao absolute right-0 mt-2 w-72 p-2 shadow-lg animate-aparecer">
                  <p className="px-2 py-1.5 text-xs font-semibold uppercase tracking-wide text-slate-400">Notificações</p>
                  {notificacoes.map((texto) => (
                    <p key={texto} className="rounded-lg px-2 py-2 text-sm text-slate-600 hover:bg-slate-50">
                      {texto}
                    </p>
                  ))}
                </div>
              )}
            </div>

            <NavLink
              to="/app/perfil"
              className="flex size-9 items-center justify-center rounded-full bg-marinho-700 text-xs font-bold text-white"
              title={usuario?.nome}
            >
              {iniciais(usuario?.nome ?? "")}
            </NavLink>
          </div>
        </header>

        <main className="flex-1 px-4 py-6 sm:px-6 lg:px-8">
          <Outlet />
        </main>

        <footer className="border-t border-slate-200 bg-white px-6 py-4 text-center text-xs text-slate-400">
          Clinify · Hospital Moinhos de Vento · Casos clínicos fictícios com finalidade educacional
        </footer>
      </div>
    </div>
  );
}
