import { useState } from "react";
import type { ReactNode } from "react";
import { Link, useParams } from "react-router-dom";
import {
  ArrowLeft,
  ArrowRight,
  CircleCheck,
  CircleX,
  ClipboardList,
  FlaskConical,
  HeartPulse,
  Lightbulb,
  RotateCcw,
  Stethoscope,
  User,
} from "lucide-react";
import { SeloDificuldade } from "../../components/Selo";
import { useProgresso } from "../../context/ProgressoContext";
import { buscarCaso } from "../../data/casos";
import type { CasoClinico, Opcao } from "../../data/casos";
import { avaliarCaso, classificarNota } from "../../lib/avaliacao";
import type { Avaliacao, RespostaAluno } from "../../lib/avaliacao";
import { NaoEncontrado } from "../NaoEncontrado";

const etapas = [
  { titulo: "Caso clínico", icone: User },
  { titulo: "Hipótese diagnóstica", icone: Stethoscope },
  { titulo: "Exames", icone: FlaskConical },
  { titulo: "Conduta", icone: HeartPulse },
  { titulo: "Prontuário", icone: ClipboardList },
];

const RESPOSTA_VAZIA: RespostaAluno = { diagnostico: null, exames: [], condutas: [], justificativa: "" };

export function Simulacao() {
  const { id } = useParams();
  const caso = buscarCaso(id);
  const { registrarResultado } = useProgresso();

  const [etapa, setEtapa] = useState(0);
  const [resposta, setResposta] = useState<RespostaAluno>(RESPOSTA_VAZIA);
  const [avaliacao, setAvaliacao] = useState<Avaliacao | null>(null);

  if (!caso) return <NaoEncontrado />;

  function alternar(campo: "exames" | "condutas", idOpcao: string) {
    setResposta((r) => ({
      ...r,
      [campo]: r[campo].includes(idOpcao) ? r[campo].filter((x) => x !== idOpcao) : [...r[campo], idOpcao],
    }));
  }

  // o aluno só avança se preencheu a etapa atual
  const podeAvancar = [
    true,
    resposta.diagnostico !== null,
    resposta.exames.length > 0,
    resposta.condutas.length > 0,
    resposta.justificativa.trim().length >= 20,
  ][etapa];

  function finalizar() {
    if (!caso) return;
    const resultado = avaliarCaso(caso, resposta);
    setAvaliacao(resultado);
    registrarResultado({ casoId: caso.id, nota: resultado.nota, diagnosticoCorreto: resultado.diagnostico.acertou });
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function refazer() {
    setResposta(RESPOSTA_VAZIA);
    setAvaliacao(null);
    setEtapa(0);
  }

  return (
    <div className="mx-auto max-w-5xl space-y-6">
      <Link to="/app/simulacoes" className="inline-flex items-center gap-1.5 text-sm font-medium text-slate-500 hover:text-marinho-700">
        <ArrowLeft className="size-4" /> Voltar para os casos
      </Link>

      <div className="flex flex-wrap items-center gap-3">
        <h1 className="text-2xl font-bold text-slate-900 sm:text-3xl">{caso.titulo}</h1>
        <SeloDificuldade dificuldade={caso.dificuldade} />
        <span className="text-sm font-semibold text-roxo-600">{caso.especialidade}</span>
      </div>

      {avaliacao ? (
        <Feedback caso={caso} resposta={resposta} avaliacao={avaliacao} aoRefazer={refazer} />
      ) : (
        <>
          {/* barra de etapas */}
          <ol className="grid grid-cols-5 gap-2">
            {etapas.map(({ titulo, icone: Icone }, indice) => (
              <li key={titulo}>
                <button
                  onClick={() => indice < etapa && setEtapa(indice)}
                  disabled={indice > etapa}
                  className="w-full text-left"
                >
                  <div className={`h-1.5 rounded-full ${indice <= etapa ? "bg-marinho-600" : "bg-slate-200"}`} />
                  <p className={`mt-2 hidden items-center gap-1.5 text-xs font-semibold sm:flex ${indice <= etapa ? "text-marinho-700" : "text-slate-400"}`}>
                    <Icone className="size-3.5" /> {titulo}
                  </p>
                </button>
              </li>
            ))}
          </ol>
          <p className="text-sm font-semibold text-marinho-700 sm:hidden">
            Etapa {etapa + 1} de {etapas.length}: {etapas[etapa].titulo}
          </p>

          <div className="grid gap-6 lg:grid-cols-[1fr_320px]">
            {/* área da etapa */}
            <section className="cartao p-5 sm:p-6 animate-aparecer" key={etapa}>
              {etapa === 0 && <DadosDoCaso caso={caso} />}

              {etapa === 1 && (
                <Pergunta titulo="Qual a sua principal hipótese diagnóstica?" subtitulo="Escolha apenas uma opção.">
                  {caso.diagnosticos.map((opcao) => (
                    <OpcaoEscolha
                      key={opcao.id}
                      tipo="radio"
                      opcao={opcao}
                      marcada={resposta.diagnostico === opcao.id}
                      aoClicar={() => setResposta((r) => ({ ...r, diagnostico: opcao.id }))}
                    />
                  ))}
                </Pergunta>
              )}

              {etapa === 2 && (
                <Pergunta titulo="Quais exames você solicitaria agora?" subtitulo="Marque todos que achar necessários. Exames desnecessários tiram pontos.">
                  {caso.exames.map((opcao) => (
                    <OpcaoEscolha
                      key={opcao.id}
                      tipo="checkbox"
                      opcao={opcao}
                      marcada={resposta.exames.includes(opcao.id)}
                      aoClicar={() => alternar("exames", opcao.id)}
                    />
                  ))}
                </Pergunta>
              )}

              {etapa === 3 && (
                <Pergunta titulo="Qual a conduta inicial?" subtitulo="Marque todas as condutas adequadas. Condutas inadequadas tiram pontos.">
                  {caso.condutas.map((opcao) => (
                    <OpcaoEscolha
                      key={opcao.id}
                      tipo="checkbox"
                      opcao={opcao}
                      marcada={resposta.condutas.includes(opcao.id)}
                      aoClicar={() => alternar("condutas", opcao.id)}
                    />
                  ))}
                </Pergunta>
              )}

              {etapa === 4 && (
                <Pergunta
                  titulo="Preencha o prontuário"
                  subtitulo="Escreva a evolução do paciente justificando seu raciocínio: diagnóstico, exames e conduta."
                >
                  <textarea
                    value={resposta.justificativa}
                    onChange={(e) => setResposta((r) => ({ ...r, justificativa: e.target.value }))}
                    rows={8}
                    placeholder="Ex.: Paciente de 58 anos com dor torácica típica e fatores de risco. Hipótese de síndrome coronariana aguda. Solicito ECG em até 10 minutos e troponina..."
                    className="w-full rounded-xl border border-slate-200 p-4 text-sm leading-relaxed outline-none transition focus:border-marinho-500 focus:ring-4 focus:ring-marinho-100"
                  />
                  <p className="text-right text-xs text-slate-400">{resposta.justificativa.trim().length} caracteres (mínimo 20)</p>
                </Pergunta>
              )}

              <div className="mt-6 flex justify-between gap-3 border-t border-slate-100 pt-5">
                <button
                  onClick={() => setEtapa(etapa - 1)}
                  disabled={etapa === 0}
                  className="rounded-xl px-4 py-2.5 text-sm font-semibold text-slate-600 hover:bg-slate-100 disabled:invisible"
                >
                  Voltar
                </button>
                {etapa < etapas.length - 1 ? (
                  <button
                    onClick={() => setEtapa(etapa + 1)}
                    disabled={!podeAvancar}
                    className="flex items-center gap-2 rounded-xl bg-marinho-700 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-marinho-800 disabled:cursor-not-allowed disabled:opacity-40"
                  >
                    Continuar <ArrowRight className="size-4" />
                  </button>
                ) : (
                  <button
                    onClick={finalizar}
                    disabled={!podeAvancar}
                    className="rounded-xl bg-gradient-to-r from-marinho-700 to-roxo-600 px-5 py-2.5 text-sm font-semibold text-white transition hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-40"
                  >
                    Finalizar e ver feedback
                  </button>
                )}
              </div>
            </section>

            {/* resumo do paciente sempre visível */}
            {etapa > 0 && (
              <aside className="cartao h-fit p-5 text-sm lg:sticky lg:top-24">
                <p className="mb-2 font-bold text-slate-900">Resumo do paciente</p>
                <p className="text-slate-600">
                  {caso.paciente.nome}, {caso.paciente.idade} anos, {caso.paciente.sexo.toLowerCase()}.
                </p>
                <p className="mt-2 text-slate-600">{caso.queixaPrincipal}</p>
                <SinaisVitais caso={caso} compacto />
              </aside>
            )}
          </div>
        </>
      )}
    </div>
  );
}

// ---------- componentes da tela ----------

function DadosDoCaso({ caso }: { caso: CasoClinico }) {
  return (
    <div className="space-y-5 text-sm leading-relaxed text-slate-700">
      <div className="flex items-center gap-3 rounded-xl bg-marinho-50 p-4">
        <div className="flex size-11 items-center justify-center rounded-full bg-marinho-700 text-white">
          <User className="size-5" />
        </div>
        <div>
          <p className="font-bold text-slate-900">Paciente {caso.paciente.nome}</p>
          <p className="text-slate-500">
            {caso.paciente.idade} anos · {caso.paciente.sexo}
          </p>
        </div>
      </div>
      <Bloco titulo="Queixa principal">{caso.queixaPrincipal}</Bloco>
      <Bloco titulo="História da doença atual">{caso.historia}</Bloco>
      <Bloco titulo="Antecedentes">{caso.antecedentes}</Bloco>
      <div>
        <p className="mb-2 text-xs font-bold uppercase tracking-wide text-slate-400">Sinais vitais</p>
        <SinaisVitais caso={caso} />
      </div>
      <Bloco titulo="Exame físico">{caso.exameFisico}</Bloco>
    </div>
  );
}

function Bloco({ titulo, children }: { titulo: string; children: ReactNode }) {
  return (
    <div>
      <p className="mb-1 text-xs font-bold uppercase tracking-wide text-slate-400">{titulo}</p>
      <p>{children}</p>
    </div>
  );
}

function SinaisVitais({ caso, compacto = false }: { caso: CasoClinico; compacto?: boolean }) {
  const sv = caso.sinaisVitais;
  const itens = [
    ["PA", sv.pa],
    ["FC", sv.fc],
    ["FR", sv.fr],
    ["Temp.", sv.temp],
    ["SpO₂", sv.sat],
  ];
  return (
    <div className={`grid gap-2 ${compacto ? "mt-3 grid-cols-2" : "grid-cols-2 sm:grid-cols-5"}`}>
      {itens.map(([rotulo, valor]) => (
        <div key={rotulo} className="rounded-lg bg-slate-50 px-3 py-2">
          <p className="text-[11px] font-semibold text-slate-400">{rotulo}</p>
          <p className="font-semibold text-slate-800">{valor}</p>
        </div>
      ))}
    </div>
  );
}

function Pergunta({ titulo, subtitulo, children }: { titulo: string; subtitulo: string; children: ReactNode }) {
  return (
    <div>
      <h2 className="text-lg font-bold text-slate-900">{titulo}</h2>
      <p className="mb-4 text-sm text-slate-500">{subtitulo}</p>
      <div className="space-y-2.5">{children}</div>
    </div>
  );
}

interface OpcaoEscolhaProps {
  tipo: "radio" | "checkbox";
  opcao: Opcao;
  marcada: boolean;
  aoClicar: () => void;
}

function OpcaoEscolha({ tipo, opcao, marcada, aoClicar }: OpcaoEscolhaProps) {
  return (
    <label
      className={`flex cursor-pointer items-start gap-3 rounded-xl border p-4 text-sm transition ${
        marcada ? "border-marinho-500 bg-marinho-50 ring-2 ring-marinho-100" : "border-slate-200 hover:border-marinho-200"
      }`}
    >
      <input type={tipo} checked={marcada} onChange={aoClicar} className="mt-0.5 size-4 accent-marinho-700" />
      <span className="text-slate-700">{opcao.texto}</span>
    </label>
  );
}

// ---------- feedback ----------

interface FeedbackProps {
  caso: CasoClinico;
  resposta: RespostaAluno;
  avaliacao: Avaliacao;
  aoRefazer: () => void;
}

function Feedback({ caso, resposta, avaliacao, aoRefazer }: FeedbackProps) {
  const classificacao = classificarNota(avaliacao.nota);
  const secoes = [
    { nome: "Hipótese diagnóstica", ...avaliacao.diagnostico },
    { nome: "Exames", ...avaliacao.exames },
    { nome: "Conduta", ...avaliacao.condutas },
    { nome: "Prontuário", ...avaliacao.prontuario },
  ];

  return (
    <div className="space-y-6 animate-aparecer">
      {/* nota */}
      <section className="cartao grid gap-6 p-6 md:grid-cols-[auto_1fr] md:items-center">
        <div
          className="mx-auto flex size-36 items-center justify-center rounded-full"
          style={{ background: `conic-gradient(#1d4f91 ${avaliacao.nota * 3.6}deg, #e2e8f0 0deg)` }}
        >
          <div className="flex size-28 flex-col items-center justify-center rounded-full bg-white">
            <span className="text-4xl font-extrabold text-slate-900">{avaliacao.nota}</span>
            <span className="text-xs text-slate-400">de 100</span>
          </div>
        </div>
        <div>
          <span className={`rounded-full px-3 py-1 text-sm font-bold ${classificacao.fundo} ${classificacao.cor}`}>
            {classificacao.texto}
          </span>
          <h2 className="mt-3 text-xl font-bold text-slate-900">Avaliação do seu raciocínio clínico</h2>
          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            {secoes.map((s) => (
              <div key={s.nome}>
                <div className="mb-1 flex justify-between text-sm">
                  <span className="text-slate-600">{s.nome}</span>
                  <span className="font-semibold text-slate-900">
                    {s.pontos}/{s.maximo}
                  </span>
                </div>
                <div className="h-2 overflow-hidden rounded-full bg-slate-100">
                  <div
                    className={`h-full rounded-full ${s.pontos / s.maximo >= 0.7 ? "bg-emerald-500" : s.pontos / s.maximo >= 0.4 ? "bg-amber-400" : "bg-rose-400"}`}
                    style={{ width: `${(s.pontos / s.maximo) * 100}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* correção detalhada */}
      <section className="cartao p-5 sm:p-6">
        <h3 className="mb-4 font-bold text-slate-900">Hipótese diagnóstica</h3>
        <ListaCorrecao opcoes={caso.diagnosticos} marcadas={resposta.diagnostico ? [resposta.diagnostico] : []} soCorretaEMarcada />
      </section>

      <section className="cartao p-5 sm:p-6">
        <h3 className="mb-4 font-bold text-slate-900">Exames complementares</h3>
        <ListaCorrecao opcoes={caso.exames} marcadas={resposta.exames} />
      </section>

      <section className="cartao p-5 sm:p-6">
        <h3 className="mb-4 font-bold text-slate-900">Conduta inicial</h3>
        <ListaCorrecao opcoes={caso.condutas} marcadas={resposta.condutas} />
      </section>

      <section className="cartao p-5 sm:p-6">
        <h3 className="mb-2 font-bold text-slate-900">Prontuário</h3>
        <p className="mb-3 whitespace-pre-wrap rounded-xl bg-slate-50 p-4 text-sm text-slate-700">{resposta.justificativa}</p>
        <div className="flex flex-wrap gap-2 text-xs">
          {avaliacao.prontuario.encontradas.map((p) => (
            <span key={p} className="rounded-full bg-emerald-50 px-2.5 py-1 font-semibold text-emerald-700">✓ {p}</span>
          ))}
          {avaliacao.prontuario.faltando.map((p) => (
            <span key={p} className="rounded-full bg-slate-100 px-2.5 py-1 text-slate-500">{p}</span>
          ))}
        </div>
        <p className="mt-2 text-xs text-slate-400">
          Termos técnicos esperados no registro. Os verdes foram encontrados no seu texto.
        </p>
      </section>

      <section className="rounded-2xl bg-gradient-to-br from-marinho-700 to-roxo-700 p-6 text-white">
        <p className="mb-2 flex items-center gap-2 font-bold">
          <Lightbulb className="size-5 text-roxo-100" /> Ponto-chave do caso
        </p>
        <p className="text-sm leading-relaxed text-white/90">{caso.explicacaoFinal}</p>
      </section>

      <div className="flex flex-col gap-3 sm:flex-row">
        <button onClick={aoRefazer} className="flex items-center justify-center gap-2 rounded-xl border border-slate-200 bg-white px-5 py-3 text-sm font-semibold text-slate-700 hover:bg-slate-50">
          <RotateCcw className="size-4" /> Refazer este caso
        </button>
        <Link to="/app/simulacoes" className="flex items-center justify-center gap-2 rounded-xl bg-marinho-700 px-5 py-3 text-sm font-semibold text-white hover:bg-marinho-800">
          Próximo caso <ArrowRight className="size-4" />
        </Link>
        <Link to="/app/desempenho" className="flex items-center justify-center gap-2 rounded-xl px-5 py-3 text-sm font-semibold text-marinho-700 hover:bg-marinho-50">
          Ver meu desempenho
        </Link>
      </div>
    </div>
  );
}

interface ListaCorrecaoProps {
  opcoes: Opcao[];
  marcadas: string[];
  soCorretaEMarcada?: boolean; // no diagnóstico mostra só a certa e a escolhida
}

function ListaCorrecao({ opcoes, marcadas, soCorretaEMarcada = false }: ListaCorrecaoProps) {
  const visiveis = soCorretaEMarcada ? opcoes.filter((o) => o.correta || marcadas.includes(o.id)) : opcoes;

  return (
    <ul className="space-y-2.5">
      {visiveis.map((opcao) => {
        const marcou = marcadas.includes(opcao.id);
        const acertou = marcou === opcao.correta; // marcou a certa ou deixou de marcar a errada

        let rotulo = "";
        if (opcao.correta && marcou) rotulo = "Você marcou · correto";
        else if (opcao.correta && !marcou) rotulo = "Faltou marcar";
        else if (!opcao.correta && marcou) rotulo = "Você marcou · inadequado";
        else rotulo = "Não marcou · correto";

        return (
          <li key={opcao.id} className={`flex gap-3 rounded-xl border p-4 text-sm ${acertou ? "border-emerald-200 bg-emerald-50/50" : "border-rose-200 bg-rose-50/50"}`}>
            {acertou ? <CircleCheck className="mt-0.5 size-5 shrink-0 text-emerald-600" /> : <CircleX className="mt-0.5 size-5 shrink-0 text-rose-500" />}
            <div>
              <p className="font-semibold text-slate-800">{opcao.texto}</p>
              <p className={`text-xs font-semibold ${acertou ? "text-emerald-700" : "text-rose-600"}`}>{rotulo}</p>
              <p className="mt-1 text-slate-600">{opcao.motivo}</p>
            </div>
          </li>
        );
      })}
    </ul>
  );
}
