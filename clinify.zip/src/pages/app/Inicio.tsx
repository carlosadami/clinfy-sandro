import { useState } from "react";
import { Link } from "react-router-dom";
import { ArrowRight, CircleCheck, Flame, Target, Trophy, X, Zap } from "lucide-react";
import { CartaoIndicador } from "../../components/CartaoIndicador";
import { SeloDificuldade } from "../../components/Selo";
import { useAuth } from "../../context/AuthContext";
import { useProgresso } from "../../context/ProgressoContext";
import { casos } from "../../data/casos";
import { desafioDoDia } from "../../data/estudos";
import { dataISO } from "../../lib/armazenamento";

export function Inicio() {
  const { usuario } = useAuth();
  const { progresso, indicadores, registrarDesafio } = useProgresso();
  const [desafioAberto, setDesafioAberto] = useState(false);
  const [escolha, setEscolha] = useState<number | null>(null);

  const desafio = desafioDoDia();
  const desafioFeitoHoje = dataISO() in progresso.desafios;

  // casos que o aluno ainda não fez aparecem primeiro como recomendação
  const feitos = new Set(progresso.resultados.map((r) => r.casoId));
  const recomendados = [...casos].sort((a, b) => Number(feitos.has(a.id)) - Number(feitos.has(b.id))).slice(0, 3);

  const ultimo = progresso.resultados[progresso.resultados.length - 1];
  const ultimoCaso = casos.find((c) => c.id === ultimo?.casoId);

  function responder(indice: number) {
    if (escolha !== null) return;
    setEscolha(indice);
    registrarDesafio(indice === desafio.correta);
  }

  return (
    <div className="mx-auto max-w-6xl space-y-6">
      {/* faixa de progresso */}
      <div className="rounded-xl border-l-4 border-marinho-600 bg-marinho-50 px-5 py-3.5 animate-aparecer">
        <p className="text-sm font-semibold text-marinho-800">Seu progresso</p>
        <p className="text-sm text-marinho-700/80">
          {ultimoCaso
            ? `Última simulação: ${ultimoCaso.especialidade} (${ultimoCaso.titulo}), nota ${ultimo.nota}.`
            : "Você ainda não fez nenhuma simulação. Que tal começar agora?"}
        </p>
      </div>

      <div>
        <h1 className="text-2xl font-bold text-slate-900 sm:text-3xl">Bem-vindo, {usuario?.nome.split(" ")[0]}!</h1>
        <p className="text-slate-500">Continue sua jornada de aprendizado médico.</p>
      </div>

      {/* indicadores */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-5">
        <CartaoIndicador
          icone={Flame}
          corIcone="bg-orange-50 text-orange-500"
          valor={String(indicadores.sequencia)}
          titulo="Dias consecutivos"
          detalhe={<span className="text-slate-400">{indicadores.sequencia > 0 ? "Sequência de estudos" : "Comece hoje!"}</span>}
        />
        <CartaoIndicador
          icone={Trophy}
          corIcone="bg-marinho-50 text-marinho-600"
          valor={String(indicadores.nivel)}
          titulo="Nível atual"
          detalhe={
            <div className="h-1.5 overflow-hidden rounded-full bg-slate-100">
              <div className="h-full rounded-full bg-marinho-600" style={{ width: `${indicadores.progressoNivel}%` }} />
            </div>
          }
        />
        <CartaoIndicador
          icone={Target}
          corIcone="bg-emerald-50 text-emerald-600"
          valor={`${indicadores.metaPercentual}%`}
          titulo="Meta diária"
          detalhe={
            <span className="text-slate-400">
              {indicadores.atividadesHoje} de {progresso.metaDiaria} atividades
            </span>
          }
        />
        <CartaoIndicador
          icone={CircleCheck}
          corIcone="bg-rose-50 text-rose-500"
          valor={`${indicadores.taxaAcerto}%`}
          titulo="Taxa de acerto"
          detalhe={
            indicadores.variacaoSemana !== null ? (
              <span className={indicadores.variacaoSemana >= 0 ? "text-emerald-600" : "text-rose-600"}>
                {indicadores.variacaoSemana >= 0 ? "+" : ""}
                {indicadores.variacaoSemana}% esta semana
              </span>
            ) : (
              <span className="text-slate-400">{indicadores.totalSimulacoes} simulações</span>
            )
          }
        />

        {/* desafio diário */}
        <div className="col-span-2 flex flex-col justify-between rounded-2xl bg-gradient-to-br from-marinho-700 to-marinho-900 p-5 text-white lg:col-span-1 animate-aparecer">
          <div>
            <p className="flex items-center gap-1.5 font-semibold">
              <Zap className="size-4 text-roxo-100" /> Desafio Diário
            </p>
            <p className="mt-1 text-sm text-white/70">
              {desafioFeitoHoje ? "Você já fez o desafio de hoje." : "Uma pergunta rápida para aquecer o raciocínio."}
            </p>
          </div>
          <button
            onClick={() => {
              setEscolha(null);
              setDesafioAberto(true);
            }}
            disabled={desafioFeitoHoje}
            className="mt-4 self-start rounded-lg bg-white px-4 py-1.5 text-sm font-semibold text-marinho-800 transition hover:bg-roxo-50 disabled:cursor-not-allowed disabled:opacity-60"
          >
            {desafioFeitoHoje ? (progresso.desafios[dataISO()] ? "Acertou ✓" : "Concluído") : "Iniciar"}
          </button>
        </div>
      </div>

      {/* recomendados */}
      <section className="cartao p-5 sm:p-6">
        <div className="mb-4 flex items-center justify-between gap-3">
          <div>
            <h2 className="font-bold text-slate-900">Casos recomendados para você</h2>
            <p className="text-sm text-slate-500">Pratique em um ambiente seguro. Errar aqui faz parte do aprendizado.</p>
          </div>
          <Link to="/app/simulacoes" className="hidden shrink-0 text-sm font-semibold text-marinho-600 hover:underline sm:block">
            Ver todos
          </Link>
        </div>
        <div className="grid gap-4 md:grid-cols-3">
          {recomendados.map((caso) => (
            <Link
              key={caso.id}
              to={`/app/simulacoes/${caso.id}`}
              className="group rounded-xl border border-slate-200 p-4 transition hover:-translate-y-0.5 hover:border-marinho-200 hover:shadow-md"
            >
              <div className="mb-2 flex items-center justify-between">
                <span className="text-xs font-semibold uppercase tracking-wide text-roxo-600">{caso.especialidade}</span>
                <SeloDificuldade dificuldade={caso.dificuldade} />
              </div>
              <p className="font-semibold text-slate-900">{caso.titulo}</p>
              <p className="mt-1 text-sm text-slate-500">{caso.resumo}</p>
              <p className="mt-3 flex items-center gap-1 text-sm font-semibold text-marinho-600">
                {feitos.has(caso.id) ? "Refazer" : "Começar"}
                <ArrowRight className="size-4 transition group-hover:translate-x-1" />
              </p>
            </Link>
          ))}
        </div>
      </section>

      {/* modal do desafio */}
      {desafioAberto && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4" role="dialog" aria-modal="true">
          <div className="cartao w-full max-w-lg p-6 animate-aparecer">
            <div className="mb-4 flex items-start justify-between gap-4">
              <p className="flex items-center gap-1.5 text-sm font-semibold text-roxo-600">
                <Zap className="size-4" /> Desafio Diário
              </p>
              <button onClick={() => setDesafioAberto(false)} className="text-slate-400 hover:text-slate-600" aria-label="Fechar">
                <X className="size-5" />
              </button>
            </div>
            <h3 className="mb-4 text-lg font-bold text-slate-900">{desafio.pergunta}</h3>
            <div className="space-y-2">
              {desafio.opcoes.map((opcao, indice) => {
                let estilo = "border-slate-200 hover:border-marinho-500 hover:bg-marinho-50";
                if (escolha !== null) {
                  if (indice === desafio.correta) estilo = "border-emerald-500 bg-emerald-50 text-emerald-800";
                  else if (indice === escolha) estilo = "border-rose-400 bg-rose-50 text-rose-700";
                  else estilo = "border-slate-200 opacity-60";
                }
                return (
                  <button
                    key={opcao}
                    onClick={() => responder(indice)}
                    className={`w-full rounded-xl border px-4 py-3 text-left text-sm font-medium transition ${estilo}`}
                  >
                    {opcao}
                  </button>
                );
              })}
            </div>
            {escolha !== null && (
              <div className={`mt-4 rounded-xl p-4 text-sm ${escolha === desafio.correta ? "bg-emerald-50 text-emerald-800" : "bg-amber-50 text-amber-800"}`}>
                <p className="font-semibold">{escolha === desafio.correta ? "Resposta correta! +20 XP" : "Não foi dessa vez."}</p>
                <p>{desafio.explicacao}</p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
