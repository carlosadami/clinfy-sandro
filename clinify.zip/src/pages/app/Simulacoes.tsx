import { useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { ArrowRight, Clock, SearchX } from "lucide-react";
import { SeloDificuldade } from "../../components/Selo";
import { useProgresso } from "../../context/ProgressoContext";
import { casos } from "../../data/casos";
import { normalizar } from "../../lib/armazenamento";

const especialidades = ["Todas", ...new Set(casos.map((c) => c.especialidade))];

export function Simulacoes() {
  const [parametros, setParametros] = useSearchParams();
  const busca = parametros.get("busca") ?? "";
  const [filtro, setFiltro] = useState("Todas");
  const { progresso } = useProgresso();

  // melhor nota de cada caso
  const melhorNota: Record<string, number> = {};
  for (const r of progresso.resultados) {
    melhorNota[r.casoId] = Math.max(melhorNota[r.casoId] ?? 0, r.nota);
  }

  const filtrados = casos.filter((caso) => {
    const texto = normalizar(`${caso.titulo} ${caso.especialidade} ${caso.resumo}`);
    const passaBusca = texto.includes(normalizar(busca));
    const passaFiltro = filtro === "Todas" || caso.especialidade === filtro;
    return passaBusca && passaFiltro;
  });

  return (
    <div className="mx-auto max-w-6xl space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900 sm:text-3xl">Simulação clínica</h1>
        <p className="text-slate-500">
          Escolha um caso, analise o paciente, preencha o prontuário e receba o feedback na hora.
        </p>
      </div>

      <div className="flex flex-wrap items-center gap-2">
        {especialidades.map((esp) => (
          <button
            key={esp}
            onClick={() => setFiltro(esp)}
            className={`rounded-full px-4 py-1.5 text-sm font-medium transition ${
              filtro === esp ? "bg-marinho-700 text-white" : "bg-white text-slate-600 ring-1 ring-slate-200 hover:ring-marinho-200"
            }`}
          >
            {esp}
          </button>
        ))}
        {busca && (
          <button
            onClick={() => setParametros({})}
            className="ml-auto rounded-full bg-roxo-50 px-3 py-1.5 text-sm text-roxo-700 hover:bg-roxo-100"
          >
            Busca: "{busca}" ✕
          </button>
        )}
      </div>

      {filtrados.length === 0 ? (
        <div className="cartao flex flex-col items-center p-10 text-center">
          <SearchX className="mb-3 size-10 text-slate-300" />
          <p className="font-semibold text-slate-700">Nenhum caso encontrado</p>
          <p className="text-sm text-slate-500">Tente outra palavra ou outra especialidade.</p>
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {filtrados.map((caso) => (
            <article key={caso.id} className="cartao flex flex-col p-5 animate-aparecer">
              <div className="mb-3 flex items-center justify-between">
                <span className="text-xs font-semibold uppercase tracking-wide text-roxo-600">{caso.especialidade}</span>
                <SeloDificuldade dificuldade={caso.dificuldade} />
              </div>
              <h2 className="font-bold text-slate-900">{caso.titulo}</h2>
              <p className="mt-1 flex-1 text-sm text-slate-500">{caso.resumo}</p>

              <div className="mt-4 flex items-center justify-between text-xs text-slate-500">
                <span className="flex items-center gap-1">
                  <Clock className="size-3.5" /> ~{caso.tempoMin} min
                </span>
                {caso.id in melhorNota ? (
                  <span className="font-semibold text-emerald-600">Melhor nota: {melhorNota[caso.id]}</span>
                ) : (
                  <span>Não realizado</span>
                )}
              </div>

              <Link
                to={`/app/simulacoes/${caso.id}`}
                className="mt-4 flex items-center justify-center gap-2 rounded-xl bg-marinho-700 py-2.5 text-sm font-semibold text-white transition hover:bg-marinho-800"
              >
                {caso.id in melhorNota ? "Refazer simulação" : "Iniciar simulação"} <ArrowRight className="size-4" />
              </Link>
            </article>
          ))}
        </div>
      )}
    </div>
  );
}
