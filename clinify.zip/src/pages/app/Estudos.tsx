import { useState } from "react";
import { ChevronLeft, ChevronRight, RotateCw, Shuffle } from "lucide-react";
import { useProgresso } from "../../context/ProgressoContext";
import { flashcards } from "../../data/estudos";

const especialidades = ["Todas", ...new Set(flashcards.map((f) => f.especialidade))];

export function Estudos() {
  const { progresso, registrarFlashcard } = useProgresso();
  const [filtro, setFiltro] = useState("Todas");
  const [ordem, setOrdem] = useState(flashcards.map((f) => f.id));
  const [indice, setIndice] = useState(0);
  const [virado, setVirado] = useState(false);
  const [vistos, setVistos] = useState<Set<number>>(new Set());

  const lista = ordem
    .map((id) => flashcards.find((f) => f.id === id)!)
    .filter((f) => filtro === "Todas" || f.especialidade === filtro);
  const atual = lista[Math.min(indice, lista.length - 1)];

  function virar() {
    // conta como revisado na primeira vez que o aluno vê a resposta
    if (!virado && atual && !vistos.has(atual.id)) {
      setVistos(new Set(vistos).add(atual.id));
      registrarFlashcard();
    }
    setVirado(!virado);
  }

  function ir(passo: number) {
    setVirado(false);
    setIndice((i) => (i + passo + lista.length) % lista.length);
  }

  function embaralhar() {
    setOrdem([...ordem].sort(() => Math.random() - 0.5));
    setIndice(0);
    setVirado(false);
  }

  function mudarFiltro(esp: string) {
    setFiltro(esp);
    setIndice(0);
    setVirado(false);
  }

  return (
    <div className="mx-auto max-w-4xl space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900 sm:text-3xl">Estudos</h1>
        <p className="text-slate-500">
          Revise conceitos rápidos com flashcards, ideal para os intervalos do dia. Você já revisou{" "}
          <strong className="text-marinho-700">{progresso.flashcardsRevisados}</strong> cartões.
        </p>
      </div>

      <div className="flex flex-wrap gap-2">
        {especialidades.map((esp) => (
          <button
            key={esp}
            onClick={() => mudarFiltro(esp)}
            className={`rounded-full px-4 py-1.5 text-sm font-medium transition ${
              filtro === esp ? "bg-marinho-700 text-white" : "bg-white text-slate-600 ring-1 ring-slate-200 hover:ring-marinho-200"
            }`}
          >
            {esp}
          </button>
        ))}
      </div>

      {atual && (
        <>
          <button onClick={virar} className={`flip block h-72 w-full sm:h-80 ${virado ? "flip-virado" : ""}`} aria-label="Virar cartão">
            <div className="flip-interno relative size-full">
              <div className="flip-face cartao absolute inset-0 flex flex-col items-center justify-center p-8 text-center">
                <span className="mb-4 rounded-full bg-roxo-50 px-3 py-1 text-xs font-semibold text-roxo-700">{atual.especialidade}</span>
                <p className="text-lg font-bold text-slate-900 sm:text-2xl">{atual.pergunta}</p>
                <p className="mt-6 flex items-center gap-1.5 text-sm text-slate-400">
                  <RotateCw className="size-4" /> Toque para ver a resposta
                </p>
              </div>
              <div className="flip-face flip-verso absolute inset-0 flex flex-col items-center justify-center rounded-2xl bg-gradient-to-br from-marinho-700 to-roxo-700 p-8 text-center text-white">
                <span className="mb-4 text-xs font-semibold uppercase tracking-widest text-white/60">Resposta</span>
                <p className="text-lg font-semibold leading-relaxed sm:text-xl">{atual.resposta}</p>
              </div>
            </div>
          </button>

          <div className="flex items-center justify-between">
            <button onClick={() => ir(-1)} className="flex items-center gap-1 rounded-xl px-4 py-2.5 text-sm font-semibold text-slate-600 hover:bg-white" aria-label="Cartão anterior">
              <ChevronLeft className="size-5" /> <span className="hidden sm:inline">Anterior</span>
            </button>
            <div className="flex items-center gap-3">
              <span className="text-sm font-semibold text-slate-500">
                {Math.min(indice, lista.length - 1) + 1} / {lista.length}
              </span>
              <button onClick={embaralhar} className="rounded-lg p-2 text-slate-500 hover:bg-white hover:text-marinho-700" title="Embaralhar" aria-label="Embaralhar">
                <Shuffle className="size-4" />
              </button>
            </div>
            <button onClick={() => ir(1)} className="flex items-center gap-1 rounded-xl bg-marinho-700 px-4 py-2.5 text-sm font-semibold text-white hover:bg-marinho-800" aria-label="Próximo cartão">
              <span className="hidden sm:inline">Próximo</span> <ChevronRight className="size-5" />
            </button>
          </div>
        </>
      )}
    </div>
  );
}
