import { Link } from "react-router-dom";
import { Activity, Award, BookOpen, Stethoscope } from "lucide-react";
import { CartaoIndicador } from "../../components/CartaoIndicador";
import { useProgresso } from "../../context/ProgressoContext";
import { casos } from "../../data/casos";
import { classificarNota } from "../../lib/avaliacao";
import { dataISO, diasAtras } from "../../lib/armazenamento";

export function Desempenho() {
  const { progresso, indicadores } = useProgresso();
  const { resultados } = progresso;

  // média por especialidade
  const porEspecialidade = [...new Set(casos.map((c) => c.especialidade))].map((esp) => {
    const notas = resultados.filter((r) => casos.find((c) => c.id === r.casoId)?.especialidade === esp).map((r) => r.nota);
    const mediaEsp = notas.length ? Math.round(notas.reduce((a, b) => a + b, 0) / notas.length) : null;
    return { esp, media: mediaEsp, quantidade: notas.length };
  });

  // atividades dos últimos 14 dias
  const ultimosDias = Array.from({ length: 14 }, (_, i) => {
    const data = diasAtras(13 - i);
    return { data, quantidade: progresso.atividadesPorDia[dataISO(data)] ?? 0 };
  });
  const maiorDia = Math.max(1, ...ultimosDias.map((d) => d.quantidade));

  const acertosDiagnostico = resultados.filter((r) => r.diagnosticoCorreto).length;
  const pontoFraco = porEspecialidade.filter((e) => e.media !== null).sort((a, b) => a.media! - b.media!)[0];

  return (
    <div className="mx-auto max-w-6xl space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900 sm:text-3xl">Desempenho</h1>
        <p className="text-slate-500">Acompanhe sua evolução e descubra onde precisa melhorar.</p>
      </div>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <CartaoIndicador icone={Stethoscope} corIcone="bg-marinho-50 text-marinho-600" valor={String(resultados.length)} titulo="Simulações feitas" />
        <CartaoIndicador icone={Award} corIcone="bg-emerald-50 text-emerald-600" valor={`${indicadores.taxaAcerto}%`} titulo="Nota média" />
        <CartaoIndicador
          icone={Activity}
          corIcone="bg-roxo-50 text-roxo-600"
          valor={resultados.length ? `${Math.round((acertosDiagnostico / resultados.length) * 100)}%` : "0%"}
          titulo="Diagnósticos corretos"
        />
        <CartaoIndicador icone={BookOpen} corIcone="bg-orange-50 text-orange-500" valor={String(progresso.flashcardsRevisados)} titulo="Flashcards revisados" />
      </div>

      {pontoFraco && (
        <div className="rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-800">
          <strong>Onde melhorar:</strong> sua menor média está em <strong>{pontoFraco.esp}</strong> ({pontoFraco.media} pontos). Que tal
          revisar os flashcards dessa área e refazer a simulação?
        </div>
      )}

      <div className="grid gap-6 lg:grid-cols-2">
        <section className="cartao p-5 sm:p-6">
          <h2 className="mb-5 font-bold text-slate-900">Média por especialidade</h2>
          <div className="space-y-4">
            {porEspecialidade.map(({ esp, media, quantidade }) => (
              <div key={esp}>
                <div className="mb-1.5 flex justify-between text-sm">
                  <span className="font-medium text-slate-700">{esp}</span>
                  <span className="text-slate-500">{media === null ? "Sem simulações" : `${media} pts · ${quantidade}x`}</span>
                </div>
                <div className="h-2.5 overflow-hidden rounded-full bg-slate-100">
                  <div className="h-full rounded-full bg-gradient-to-r from-marinho-600 to-roxo-500 transition-all" style={{ width: `${media ?? 0}%` }} />
                </div>
              </div>
            ))}
          </div>
        </section>

        <section className="cartao p-5 sm:p-6">
          <h2 className="mb-5 font-bold text-slate-900">Atividades nos últimos 14 dias</h2>
          <div className="flex items-end gap-1.5">
            {ultimosDias.map(({ data, quantidade }) => (
              <div key={data.toISOString()} className="flex flex-1 flex-col items-center gap-1.5">
                <div className="flex h-36 w-full items-end">
                  <div
                    className={`w-full rounded-t-md transition-all ${quantidade ? "bg-gradient-to-t from-marinho-700 to-roxo-500" : "bg-slate-100"}`}
                    style={{ height: `${Math.max(4, (quantidade / maiorDia) * 100)}%` }}
                    title={`${quantidade} atividade(s)`}
                  />
                </div>
                <span className="text-[10px] text-slate-400">{data.getDate()}</span>
              </div>
            ))}
          </div>
        </section>
      </div>

      <section className="cartao overflow-hidden">
        <h2 className="p-5 font-bold text-slate-900 sm:p-6 sm:pb-4">Histórico de simulações</h2>
        {resultados.length === 0 ? (
          <p className="px-6 pb-6 text-sm text-slate-500">
            Nenhuma simulação ainda.{" "}
            <Link to="/app/simulacoes" className="font-semibold text-marinho-600 hover:underline">
              Fazer a primeira
            </Link>
          </p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[520px] text-left text-sm">
              <thead className="bg-slate-50 text-xs uppercase tracking-wide text-slate-400">
                <tr>
                  <th className="px-6 py-3 font-semibold">Data</th>
                  <th className="px-6 py-3 font-semibold">Caso</th>
                  <th className="px-6 py-3 font-semibold">Diagnóstico</th>
                  <th className="px-6 py-3 font-semibold">Nota</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {[...resultados].reverse().map((r) => {
                  const caso = casos.find((c) => c.id === r.casoId);
                  const c = classificarNota(r.nota);
                  return (
                    <tr key={r.data} className="hover:bg-slate-50/60">
                      <td className="px-6 py-3 text-slate-500">{new Date(r.data).toLocaleDateString("pt-BR")}</td>
                      <td className="px-6 py-3">
                        <p className="font-medium text-slate-800">{caso?.titulo}</p>
                        <p className="text-xs text-slate-400">{caso?.especialidade}</p>
                      </td>
                      <td className="px-6 py-3">{r.diagnosticoCorreto ? "✅ Correto" : "❌ Incorreto"}</td>
                      <td className="px-6 py-3">
                        <span className={`rounded-full px-2.5 py-1 text-xs font-bold ${c.fundo} ${c.cor}`}>{r.nota}</span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}
