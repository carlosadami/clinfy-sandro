import { useState } from "react";
import type { FormEvent } from "react";
import { Check } from "lucide-react";
import { useAuth } from "../../context/AuthContext";
import { useProgresso } from "../../context/ProgressoContext";
import { iniciais } from "../../lib/armazenamento";

export function Perfil() {
  const { usuario, atualizar } = useAuth();
  const { progresso, indicadores, alterarMeta, resetarProgresso } = useProgresso();

  const [nome, setNome] = useState(usuario?.nome ?? "");
  const [semestre, setSemestre] = useState(usuario?.semestre ?? "");
  const [instituicao, setInstituicao] = useState(usuario?.instituicao ?? "");
  const [salvo, setSalvo] = useState(false);
  const [confirmarReset, setConfirmarReset] = useState(false);

  function salvarPerfil(evento: FormEvent) {
    evento.preventDefault();
    atualizar({ nome: nome.trim() || usuario?.nome, semestre, instituicao });
    setSalvo(true);
    setTimeout(() => setSalvo(false), 2500);
  }

  if (!usuario) return null;

  return (
    <div className="mx-auto max-w-4xl space-y-6">
      <h1 className="text-2xl font-bold text-slate-900 sm:text-3xl">Meu perfil</h1>

      <section className="cartao flex flex-col items-center gap-5 p-6 text-center sm:flex-row sm:text-left">
        <div className="flex size-20 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-marinho-700 to-roxo-600 text-2xl font-bold text-white">
          {iniciais(usuario.nome)}
        </div>
        <div className="flex-1">
          <p className="text-xl font-bold text-slate-900">{usuario.nome}</p>
          <p className="text-sm text-slate-500">{usuario.email}</p>
          <p className="text-sm text-slate-500">
            {usuario.semestre} · {usuario.instituicao}
          </p>
        </div>
        <div className="grid grid-cols-3 gap-6 text-center">
          <div>
            <p className="text-2xl font-bold text-marinho-700">{indicadores.nivel}</p>
            <p className="text-xs text-slate-500">Nível</p>
          </div>
          <div>
            <p className="text-2xl font-bold text-marinho-700">{indicadores.xp}</p>
            <p className="text-xs text-slate-500">XP</p>
          </div>
          <div>
            <p className="text-2xl font-bold text-marinho-700">{indicadores.sequencia}</p>
            <p className="text-xs text-slate-500">Dias seguidos</p>
          </div>
        </div>
      </section>

      <form onSubmit={salvarPerfil} className="cartao space-y-4 p-6">
        <h2 className="font-bold text-slate-900">Dados pessoais</h2>
        <div className="grid gap-4 sm:grid-cols-2">
          <Campo rotulo="Nome completo" valor={nome} aoMudar={setNome} />
          <Campo rotulo="E-mail" valor={usuario.email} desabilitado />
          <Campo rotulo="Semestre" valor={semestre} aoMudar={setSemestre} />
          <Campo rotulo="Instituição" valor={instituicao} aoMudar={setInstituicao} />
        </div>
        <div className="flex items-center gap-3">
          <button className="rounded-xl bg-marinho-700 px-5 py-2.5 text-sm font-semibold text-white hover:bg-marinho-800">Salvar alterações</button>
          {salvo && (
            <span className="flex items-center gap-1 text-sm font-medium text-emerald-600 animate-aparecer">
              <Check className="size-4" /> Salvo!
            </span>
          )}
        </div>
      </form>

      <section className="cartao space-y-4 p-6">
        <div>
          <h2 className="font-bold text-slate-900">Meta diária</h2>
          <p className="text-sm text-slate-500">Quantas atividades (simulações, desafios ou blocos de 5 flashcards) você quer fazer por dia?</p>
        </div>
        <div className="flex flex-wrap gap-2">
          {[2, 3, 4, 5, 6].map((meta) => (
            <button
              key={meta}
              onClick={() => alterarMeta(meta)}
              className={`size-12 rounded-xl text-lg font-bold transition ${
                progresso.metaDiaria === meta ? "bg-marinho-700 text-white" : "bg-slate-50 text-slate-600 ring-1 ring-slate-200 hover:ring-marinho-200"
              }`}
            >
              {meta}
            </button>
          ))}
        </div>
      </section>

      <section className="cartao space-y-3 border-rose-100 p-6">
        <h2 className="font-bold text-slate-900">Zerar progresso</h2>
        <p className="text-sm text-slate-500">Apaga suas simulações, desafios e flashcards revisados. Não é possível desfazer.</p>
        {confirmarReset ? (
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => {
                resetarProgresso();
                setConfirmarReset(false);
              }}
              className="rounded-xl bg-rose-600 px-4 py-2 text-sm font-semibold text-white hover:bg-rose-700"
            >
              Sim, apagar tudo
            </button>
            <button onClick={() => setConfirmarReset(false)} className="rounded-xl px-4 py-2 text-sm font-semibold text-slate-600 hover:bg-slate-100">
              Cancelar
            </button>
          </div>
        ) : (
          <button onClick={() => setConfirmarReset(true)} className="rounded-xl border border-rose-200 px-4 py-2 text-sm font-semibold text-rose-600 hover:bg-rose-50">
            Zerar meu progresso
          </button>
        )}
      </section>
    </div>
  );
}

interface CampoProps {
  rotulo: string;
  valor: string;
  aoMudar?: (valor: string) => void;
  desabilitado?: boolean;
}

function Campo({ rotulo, valor, aoMudar, desabilitado }: CampoProps) {
  return (
    <label className="block text-sm">
      <span className="mb-1 block font-medium text-slate-700">{rotulo}</span>
      <input
        value={valor}
        onChange={(e) => aoMudar?.(e.target.value)}
        disabled={desabilitado}
        className="w-full rounded-xl border border-slate-200 px-3.5 py-2.5 outline-none transition focus:border-marinho-500 focus:ring-4 focus:ring-marinho-100 disabled:bg-slate-50 disabled:text-slate-400"
      />
    </label>
  );
}
