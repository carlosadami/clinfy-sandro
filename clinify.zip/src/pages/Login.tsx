import { useState } from "react";
import type { FormEvent } from "react";
import { Link, Navigate, useLocation, useNavigate } from "react-router-dom";
import { CircleCheck, Eye, EyeOff, Info } from "lucide-react";
import { Logo } from "../components/Logo";
import { useAuth, USUARIO_TESTE } from "../context/AuthContext";

type Modo = "entrar" | "cadastrar";

export function Login() {
  const { usuario, entrar, cadastrar } = useAuth();
  const navegar = useNavigate();
  const local = useLocation();
  const destino = (local.state as { de?: string } | null)?.de ?? "/app";

  const [modo, setModo] = useState<Modo>("entrar");
  const [nome, setNome] = useState("");
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [verSenha, setVerSenha] = useState(false);
  const [erro, setErro] = useState("");

  if (usuario) return <Navigate to="/app" replace />;

  function enviar(evento: FormEvent) {
    evento.preventDefault();
    setErro("");

    if (!email.includes("@")) return setErro("Digite um e-mail válido.");
    if (senha.length < 6) return setErro("A senha precisa ter pelo menos 6 caracteres.");

    let mensagem: string | null;
    if (modo === "entrar") {
      mensagem = entrar(email, senha);
    } else {
      if (nome.trim().length < 3) return setErro("Digite seu nome completo.");
      mensagem = cadastrar({ nome: nome.trim(), email, senha, semestre: "1º semestre", instituicao: "Faculdade Moinhos de Vento" });
    }

    if (mensagem) setErro(mensagem);
    else navegar(destino, { replace: true });
  }

  function preencherTeste() {
    setModo("entrar");
    setEmail(USUARIO_TESTE.email);
    setSenha(USUARIO_TESTE.senha);
    setErro("");
  }

  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      {/* lado esquerdo (só no computador) */}
      <div className="relative hidden overflow-hidden bg-gradient-to-br from-marinho-800 via-marinho-700 to-roxo-700 p-12 text-white lg:flex lg:flex-col lg:justify-between">
        <div className="absolute -right-24 -top-24 size-96 rounded-full bg-roxo-500/30 blur-3xl" />
        <div className="absolute -bottom-32 -left-16 size-96 rounded-full bg-marinho-500/40 blur-3xl" />
        <Link to="/" className="relative">
          <Logo claro />
        </Link>
        <div className="relative">
          <h2 className="text-4xl font-bold leading-tight">A prática que transforma o aprendizado.</h2>
          <ul className="mt-8 space-y-3 text-white/85">
            {["Casos clínicos realistas, sem risco a pacientes", "Feedback instantâneo do raciocínio e do prontuário", "Estude pelo celular em qualquer intervalo"].map((item) => (
              <li key={item} className="flex items-center gap-3">
                <CircleCheck className="size-5 text-roxo-100" /> {item}
              </li>
            ))}
          </ul>
        </div>
        <p className="relative text-sm text-white/60">Clinify · Hospital Moinhos de Vento</p>
      </div>

      {/* formulário */}
      <div className="flex items-center justify-center p-6 sm:p-10">
        <div className="w-full max-w-md animate-aparecer">
          <Link to="/" className="mb-8 inline-block lg:hidden">
            <Logo />
          </Link>

          <h1 className="text-2xl font-bold text-slate-900">{modo === "entrar" ? "Entrar na sua conta" : "Criar conta"}</h1>
          <p className="mb-6 text-slate-500">{modo === "entrar" ? "Continue de onde parou." : "Comece a praticar em poucos segundos."}</p>

          <div className="mb-6 grid grid-cols-2 rounded-xl bg-slate-100 p-1 text-sm font-semibold">
            {(["entrar", "cadastrar"] as Modo[]).map((m) => (
              <button
                key={m}
                type="button"
                onClick={() => {
                  setModo(m);
                  setErro("");
                }}
                className={`rounded-lg py-2 transition ${modo === m ? "bg-white text-marinho-700 shadow-sm" : "text-slate-500"}`}
              >
                {m === "entrar" ? "Entrar" : "Criar conta"}
              </button>
            ))}
          </div>

          <form onSubmit={enviar} className="space-y-4" noValidate>
            {modo === "cadastrar" && (
              <Campo rotulo="Nome completo" tipo="text" valor={nome} aoMudar={setNome} autoComplete="name" />
            )}
            <Campo rotulo="E-mail" tipo="email" valor={email} aoMudar={setEmail} autoComplete="email" />
            <div className="relative">
              <Campo rotulo="Senha" tipo={verSenha ? "text" : "password"} valor={senha} aoMudar={setSenha} autoComplete={modo === "entrar" ? "current-password" : "new-password"} />
              <button
                type="button"
                onClick={() => setVerSenha(!verSenha)}
                className="absolute bottom-2.5 right-3 text-slate-400 hover:text-slate-600"
                aria-label={verSenha ? "Esconder senha" : "Mostrar senha"}
              >
                {verSenha ? <EyeOff className="size-5" /> : <Eye className="size-5" />}
              </button>
            </div>

            {erro && <p className="rounded-lg bg-rose-50 px-3 py-2 text-sm font-medium text-rose-600">{erro}</p>}

            <button className="w-full rounded-xl bg-marinho-700 py-3 text-sm font-semibold text-white transition hover:bg-marinho-800">
              {modo === "entrar" ? "Entrar" : "Criar conta e começar"}
            </button>
          </form>

          <div className="mt-6 flex gap-3 rounded-xl border border-marinho-100 bg-marinho-50 p-4 text-sm text-marinho-800">
            <Info className="mt-0.5 size-5 shrink-0" />
            <div>
              <p className="font-semibold">Conta de teste</p>
              <p className="text-marinho-700/80">
                {USUARIO_TESTE.email} · senha {USUARIO_TESTE.senha}
              </p>
              <button onClick={preencherTeste} className="mt-1 font-semibold text-marinho-700 underline underline-offset-2">
                Preencher automaticamente
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

interface CampoProps {
  rotulo: string;
  tipo: string;
  valor: string;
  aoMudar: (v: string) => void;
  autoComplete?: string;
}

function Campo({ rotulo, tipo, valor, aoMudar, autoComplete }: CampoProps) {
  return (
    <label className="block text-sm">
      <span className="mb-1 block font-medium text-slate-700">{rotulo}</span>
      <input
        type={tipo}
        value={valor}
        onChange={(e) => aoMudar(e.target.value)}
        autoComplete={autoComplete}
        className="w-full rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 pr-10 outline-none transition focus:border-marinho-500 focus:ring-4 focus:ring-marinho-100"
      />
    </label>
  );
}
