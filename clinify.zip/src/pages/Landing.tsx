import { useState } from "react";
import { Link } from "react-router-dom";
import {
  ArrowRight,
  BrainCircuit,
  ClipboardCheck,
  Menu,
  ShieldCheck,
  Smartphone,
  Stethoscope,
  TrendingUp,
  X,
} from "lucide-react";
import { Logo } from "../components/Logo";

// Dados da pesquisa "A voz dos alunos" (apresentação do grupo)
const pesquisa = [
  { item: "Teoria x prática", valor: 100 },
  { item: "Tempo de aula", valor: 75 },
  { item: "Dificuldade do conteúdo", valor: 75 },
  { item: "Medo de errar", valor: 75 },
  { item: "Memorização", valor: 50 },
  { item: "Cenários clínicos", valor: 50 },
  { item: "Quantidade de aula", valor: 25 },
  { item: "Horários difíceis", valor: 25 },
  { item: "Preocupação com notas", valor: 25 },
];

const pilares = [
  {
    icone: ShieldCheck,
    titulo: "Ambiente clínico seguro",
    texto: "Permite errar, testar hipóteses diagnósticas e aperfeiçoar condutas sem qualquer risco a pacientes reais.",
  },
  {
    icone: TrendingUp,
    titulo: "Autopercepção e caminho",
    texto: "Avaliação instantânea do raciocínio clínico e do preenchimento de prontuário, mostrando onde o aluno precisa melhorar.",
  },
  {
    icone: Smartphone,
    titulo: "Estudo adaptado à rotina",
    texto: "Interface leve e responsiva para revisar casos e praticar em qualquer intervalo pelo celular.",
  },
];

const passos = [
  { icone: Stethoscope, titulo: "Analise o paciente", texto: "Leia a história, os sinais vitais e o exame físico de um caso clínico realista." },
  { icone: BrainCircuit, titulo: "Tome as decisões", texto: "Escolha a hipótese diagnóstica, os exames e a conduta, como faria no plantão." },
  { icone: ClipboardCheck, titulo: "Receba o feedback", texto: "Veja na hora sua nota, o que acertou, o que errou e o porquê de cada resposta." },
];

const linksMenu = [
  { href: "#problema", texto: "O problema" },
  { href: "#solucao", texto: "A solução" },
  { href: "#como-funciona", texto: "Como funciona" },
];

export function Landing() {
  const [menuAberto, setMenuAberto] = useState(false);

  return (
    <div className="overflow-x-hidden bg-white">
      {/* ===== Cabeçalho ===== */}
      <header className="sticky top-0 z-40 border-b border-slate-100 bg-white/85 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-4">
          <Link to="/">
            <Logo />
          </Link>

          <nav className="hidden items-center gap-8 text-sm font-medium text-slate-600 md:flex">
            {linksMenu.map((l) => (
              <a key={l.href} href={l.href} className="hover:text-marinho-700">
                {l.texto}
              </a>
            ))}
            <Link to="/login" className="rounded-xl bg-marinho-700 px-5 py-2.5 font-semibold text-white hover:bg-marinho-800">
              Entrar
            </Link>
          </nav>

          <button onClick={() => setMenuAberto(!menuAberto)} className="rounded-lg p-2 text-slate-700 md:hidden" aria-label="Abrir menu">
            {menuAberto ? <X className="size-6" /> : <Menu className="size-6" />}
          </button>
        </div>

        {menuAberto && (
          <nav className="space-y-1 border-t border-slate-100 px-5 py-4 md:hidden animate-aparecer">
            {linksMenu.map((l) => (
              <a key={l.href} href={l.href} onClick={() => setMenuAberto(false)} className="block rounded-lg px-3 py-2.5 text-slate-700 hover:bg-slate-50">
                {l.texto}
              </a>
            ))}
            <Link to="/login" className="mt-2 block rounded-xl bg-marinho-700 px-3 py-3 text-center font-semibold text-white">
              Entrar
            </Link>
          </nav>
        )}
      </header>

      {/* ===== Hero ===== */}
      <section className="relative">
        <div className="pointer-events-none absolute right-0 top-10 hidden w-[40%] max-w-md flex-col gap-3 lg:flex" aria-hidden="true">
          <div className="h-32 rounded-t-full bg-[radial-gradient(ellipse_at_bottom,#7c4dcc_0%,transparent_70%)] opacity-70" />
          <div className="h-32 rounded-t-full bg-[radial-gradient(ellipse_at_bottom,#4a3aa8_0%,transparent_70%)] opacity-70" />
          <div className="h-32 rounded-t-full bg-[radial-gradient(ellipse_at_bottom,#1d4f91_0%,transparent_70%)] opacity-70" />
        </div>

        <div className="relative mx-auto max-w-6xl px-5 py-16 sm:py-24 lg:py-28">
          <div className="max-w-2xl animate-aparecer">
            <span className="inline-flex items-center gap-2 rounded-full bg-roxo-50 px-3 py-1 text-xs font-semibold text-roxo-700">
              <span className="size-1.5 rounded-full bg-roxo-500" /> Para estudantes de Medicina
            </span>
            <h1 className="mt-5 border-l-4 border-marinho-700 pl-5 text-4xl font-bold leading-tight text-slate-800 sm:text-6xl">
              A prática que transforma o aprendizado
            </h1>
            <p className="mt-6 text-lg text-slate-500">
              O <strong className="text-marinho-700">Clinify</strong> é o app de estudos que leva o aluno da teoria para a decisão
              clínica: casos realistas, prontuário e feedback na hora, de forma inovadora, mas com uma abordagem que ele já conhece.
            </p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <Link to="/login" className="flex items-center justify-center gap-2 rounded-xl bg-marinho-700 px-6 py-3.5 font-semibold text-white shadow-lg shadow-marinho-700/20 hover:bg-marinho-800">
                Começar a praticar <ArrowRight className="size-5" />
              </Link>
              <a href="#como-funciona" className="flex items-center justify-center rounded-xl border border-slate-200 px-6 py-3.5 font-semibold text-slate-700 hover:bg-slate-50">
                Ver como funciona
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* ===== O problema ===== */}
      <section id="problema" className="scroll-mt-20 bg-fundo py-20">
        <div className="mx-auto max-w-6xl px-5">
          <div className="grid gap-10 lg:grid-cols-[1fr_1.3fr] lg:items-center">
            <div>
              <p className="text-sm font-bold uppercase tracking-widest text-roxo-600">A voz dos alunos</p>
              <h2 className="mt-2 text-3xl font-bold text-slate-800 sm:text-4xl">A insegurança na prática e o impacto na saúde</h2>
              <p className="mt-4 text-slate-600">
                A transição da teoria para a decisão clínica gera ansiedade e o receio de cometer erros na frente do paciente. Na
                nossa pesquisa com estudantes, a distância entre teoria e prática foi a dificuldade mais citada.
              </p>
              <div className="mt-6 rounded-2xl border border-rose-100 bg-white p-5">
                <p className="text-4xl font-extrabold text-rose-500">16%</p>
                <p className="mt-1 text-sm text-slate-600">
                  dos danos graves a pacientes estão ligados a falhas no diagnóstico, e a maioria dos casos pode ser evitada.
                </p>
                <p className="mt-2 text-xs text-slate-400">Fonte: CNN Brasil, 17/09/2024</p>
              </div>
            </div>

            <div className="cartao p-6">
              <p className="mb-5 text-sm font-semibold text-slate-700">Principais dificuldades citadas (% de marcações)</p>
              <div className="space-y-3">
                {pesquisa.map(({ item, valor }) => (
                  <div key={item} className="grid grid-cols-[140px_1fr_40px] items-center gap-3 text-sm sm:grid-cols-[180px_1fr_40px]">
                    <span className="text-slate-600">{item}</span>
                    <div className="h-3 overflow-hidden rounded-full bg-slate-100">
                      <div className="h-full rounded-full bg-marinho-600" style={{ width: `${valor}%` }} />
                    </div>
                    <span className="text-right font-semibold text-slate-700">{valor}%</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ===== A solução ===== */}
      <section id="solucao" className="scroll-mt-20 py-20">
        <div className="mx-auto max-w-6xl px-5">
          <div className="mx-auto max-w-2xl text-center">
            <p className="text-sm font-bold uppercase tracking-widest text-roxo-600">A solução</p>
            <h2 className="mt-2 text-3xl font-bold text-slate-800 sm:text-4xl">O impacto na formação médica</h2>
          </div>
          <div className="mt-12 grid gap-6 md:grid-cols-3">
            {pilares.map(({ icone: Icone, titulo, texto }) => (
              <div key={titulo} className="cartao p-7 transition hover:-translate-y-1 hover:shadow-lg">
                <div className="mb-5 inline-flex size-12 items-center justify-center rounded-xl bg-gradient-to-br from-marinho-700 to-roxo-600 text-white">
                  <Icone className="size-6" />
                </div>
                <h3 className="text-lg font-bold text-slate-800">{titulo}</h3>
                <p className="mt-2 text-slate-500">{texto}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ===== Como funciona ===== */}
      <section id="como-funciona" className="scroll-mt-20 bg-marinho-800 py-20 text-white">
        <div className="mx-auto max-w-6xl px-5">
          <div className="mx-auto max-w-2xl text-center">
            <p className="text-sm font-bold uppercase tracking-widest text-roxo-100">Como funciona</p>
            <h2 className="mt-2 text-3xl font-bold sm:text-4xl">Do caso clínico ao feedback em minutos</h2>
          </div>
          <div className="mt-12 grid gap-8 md:grid-cols-3">
            {passos.map(({ icone: Icone, titulo, texto }, i) => (
              <div key={titulo} className="rounded-2xl bg-white/5 p-7 ring-1 ring-white/10">
                <div className="mb-4 flex items-center gap-3">
                  <span className="flex size-10 items-center justify-center rounded-full bg-roxo-500 font-bold">{i + 1}</span>
                  <Icone className="size-6 text-roxo-100" />
                </div>
                <h3 className="text-lg font-bold">{titulo}</h3>
                <p className="mt-2 text-white/70">{texto}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ===== Chamada final ===== */}
      <section className="py-20">
        <div className="mx-auto max-w-4xl px-5">
          <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-marinho-700 to-roxo-700 px-8 py-14 text-center text-white">
            <div className="absolute -right-16 -top-16 size-56 rounded-full bg-white/10" />
            <h2 className="relative text-3xl font-bold sm:text-4xl">Vem com a gente implementar um estudo mais tech!</h2>
            <p className="relative mt-3 text-white/80">Crie sua conta grátis ou use a conta de teste e comece agora.</p>
            <Link to="/login" className="relative mt-8 inline-flex items-center gap-2 rounded-xl bg-white px-6 py-3.5 font-semibold text-marinho-800 hover:bg-roxo-50">
              Acessar o Clinify <ArrowRight className="size-5" />
            </Link>
          </div>
        </div>
      </section>

      <footer className="border-t border-slate-100 py-8">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-5 text-sm text-slate-500 sm:flex-row">
          <Logo tamanho={28} />
          <p>Desenvolvido pelo Grupo Dev.Ak · Faculdade Moinhos de Vento</p>
        </div>
      </footer>
    </div>
  );
}
