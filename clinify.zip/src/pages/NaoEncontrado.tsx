import { Link } from "react-router-dom";
import { Logo } from "../components/Logo";

export function NaoEncontrado() {
  return (
    <div className="flex min-h-[60vh] flex-col items-center justify-center p-6 text-center">
      <Logo tamanho={48} comTexto={false} />
      <p className="mt-6 text-6xl font-extrabold text-marinho-700">404</p>
      <p className="mt-2 text-lg font-semibold text-slate-800">Página não encontrada</p>
      <p className="text-slate-500">O endereço que você tentou acessar não existe.</p>
      <Link to="/" className="mt-6 rounded-xl bg-marinho-700 px-5 py-2.5 text-sm font-semibold text-white hover:bg-marinho-800">
        Voltar ao início
      </Link>
    </div>
  );
}
