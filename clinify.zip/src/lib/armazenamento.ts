// =========================================================
// Funções para salvar e ler dados no localStorage do navegador.
// Como o projeto não tem back-end, os usuários e o progresso
// ficam salvos no próprio navegador de quem está usando.
// =========================================================

export function ler<T>(chave: string, padrao: T): T {
  try {
    const texto = localStorage.getItem(chave);
    return texto ? (JSON.parse(texto) as T) : padrao;
  } catch {
    return padrao;
  }
}

export function salvar<T>(chave: string, valor: T) {
  try {
    localStorage.setItem(chave, JSON.stringify(valor));
  } catch {
    // navegador sem espaço ou em modo restrito: o app continua funcionando sem salvar
  }
}

export function remover(chave: string) {
  try {
    localStorage.removeItem(chave);
  } catch {
    // ignora
  }
}

/** Data no formato AAAA-MM-DD (usada como chave dos dias de estudo). */
export function dataISO(data = new Date()) {
  const ano = data.getFullYear();
  const mes = String(data.getMonth() + 1).padStart(2, "0");
  const dia = String(data.getDate()).padStart(2, "0");
  return `${ano}-${mes}-${dia}`;
}

export function diasAtras(quantidade: number) {
  const data = new Date();
  data.setDate(data.getDate() - quantidade);
  return data;
}

/** Remove acentos e deixa minúsculo, para comparar textos. */
export function normalizar(texto: string) {
  return texto
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase();
}

export function iniciais(nome: string) {
  const partes = nome.trim().split(/\s+/);
  const primeira = partes[0]?.[0] ?? "";
  const ultima = partes.length > 1 ? partes[partes.length - 1][0] : "";
  return (primeira + ultima).toUpperCase();
}
