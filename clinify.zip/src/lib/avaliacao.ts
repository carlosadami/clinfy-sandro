// =========================================================
// Avaliação instantânea do raciocínio clínico e do prontuário.
//
// Nota final (0 a 100):
//   Hipótese diagnóstica .... 40 pontos
//   Exames complementares ... 25 pontos
//   Conduta inicial ......... 25 pontos
//   Prontuário (justificativa) 10 pontos
// =========================================================

import type { CasoClinico, Opcao } from "../data/casos";
import { normalizar } from "./armazenamento";

export interface RespostaAluno {
  diagnostico: string | null;
  exames: string[];
  condutas: string[];
  justificativa: string;
}

export interface ResultadoSecao {
  pontos: number;
  maximo: number;
}

export interface Avaliacao {
  nota: number;
  diagnostico: ResultadoSecao & { acertou: boolean };
  exames: ResultadoSecao;
  condutas: ResultadoSecao;
  prontuario: ResultadoSecao & { encontradas: string[]; faltando: string[] };
}

export const PESOS = { diagnostico: 40, exames: 25, condutas: 25, prontuario: 10 };

/**
 * Pontua uma lista de múltipla escolha.
 * Cada opção correta marcada soma, cada opção errada marcada desconta.
 * A nota nunca fica negativa.
 */
function pontuarMultipla(opcoes: Opcao[], marcadas: string[], maximo: number): ResultadoSecao {
  const corretas = opcoes.filter((opcao) => opcao.correta);
  const valorPorAcerto = maximo / corretas.length;

  let pontos = 0;
  for (const opcao of opcoes) {
    if (!marcadas.includes(opcao.id)) continue;
    pontos += opcao.correta ? valorPorAcerto : -valorPorAcerto;
  }

  return { pontos: Math.max(0, Math.round(pontos)), maximo };
}

function avaliarProntuario(caso: CasoClinico, texto: string) {
  const textoNormalizado = normalizar(texto);
  const encontradas = caso.palavrasChave.filter((palavra) => textoNormalizado.includes(palavra));
  const faltando = caso.palavrasChave.filter((palavra) => !encontradas.includes(palavra));

  // metade dos pontos por escrever uma justificativa completa,
  // a outra metade por usar os termos técnicos esperados
  const completo = texto.trim().length >= 40 ? PESOS.prontuario / 2 : 0;
  const termos = Math.min(encontradas.length / 3, 1) * (PESOS.prontuario / 2);

  return { pontos: Math.round(completo + termos), maximo: PESOS.prontuario, encontradas, faltando };
}

export function avaliarCaso(caso: CasoClinico, resposta: RespostaAluno): Avaliacao {
  const opcaoCorreta = caso.diagnosticos.find((opcao) => opcao.correta);
  const acertou = resposta.diagnostico === opcaoCorreta?.id;

  const diagnostico = { pontos: acertou ? PESOS.diagnostico : 0, maximo: PESOS.diagnostico, acertou };
  const exames = pontuarMultipla(caso.exames, resposta.exames, PESOS.exames);
  const condutas = pontuarMultipla(caso.condutas, resposta.condutas, PESOS.condutas);
  const prontuario = avaliarProntuario(caso, resposta.justificativa);

  const nota = diagnostico.pontos + exames.pontos + condutas.pontos + prontuario.pontos;

  return { nota, diagnostico, exames, condutas, prontuario };
}

export function classificarNota(nota: number) {
  if (nota >= 85) return { texto: "Excelente", cor: "text-emerald-600", fundo: "bg-emerald-50" };
  if (nota >= 70) return { texto: "Bom", cor: "text-marinho-600", fundo: "bg-marinho-50" };
  if (nota >= 50) return { texto: "Regular", cor: "text-amber-600", fundo: "bg-amber-50" };
  return { texto: "Precisa revisar", cor: "text-rose-600", fundo: "bg-rose-50" };
}
