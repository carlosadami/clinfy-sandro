// =========================================================
// Autenticação simulada (front-end).
// Os usuários ficam no localStorage. Já existe um usuário de teste
// criado automaticamente (dados no INTEGRANTES.TXT e no README).
// =========================================================

import { createContext, useContext, useState } from "react";
import type { ReactNode } from "react";
import { ler, remover, salvar } from "../lib/armazenamento";

export interface Usuario {
  nome: string;
  email: string;
  senha: string;
  semestre: string;
  instituicao: string;
}

export const USUARIO_TESTE: Usuario = {
  nome: "Aluno Teste",
  email: "aluno@clinify.com",
  senha: "clinify123",
  semestre: "5º semestre",
  instituicao: "Faculdade Moinhos de Vento",
};

const CHAVE_USUARIOS = "clinify:usuarios";
const CHAVE_SESSAO = "clinify:sessao";

function lerUsuarios(): Usuario[] {
  const usuarios = ler<Usuario[]>(CHAVE_USUARIOS, []);
  // garante que o usuário de teste sempre exista
  if (!usuarios.some((u) => u.email === USUARIO_TESTE.email)) {
    usuarios.push(USUARIO_TESTE);
    salvar(CHAVE_USUARIOS, usuarios);
  }
  return usuarios;
}

interface AuthContextTipo {
  usuario: Usuario | null;
  entrar: (email: string, senha: string) => string | null; // devolve mensagem de erro ou null
  cadastrar: (dados: Usuario) => string | null;
  atualizar: (dados: Partial<Usuario>) => void;
  sair: () => void;
}

const AuthContext = createContext<AuthContextTipo | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [usuario, setUsuario] = useState<Usuario | null>(() => {
    const email = ler<string | null>(CHAVE_SESSAO, null);
    return lerUsuarios().find((u) => u.email === email) ?? null;
  });

  function entrar(email: string, senha: string) {
    const encontrado = lerUsuarios().find((u) => u.email === email.trim().toLowerCase());
    if (!encontrado) return "E-mail não cadastrado.";
    if (encontrado.senha !== senha) return "Senha incorreta.";
    salvar(CHAVE_SESSAO, encontrado.email);
    setUsuario(encontrado);
    return null;
  }

  function cadastrar(dados: Usuario) {
    const usuarios = lerUsuarios();
    const email = dados.email.trim().toLowerCase();
    if (usuarios.some((u) => u.email === email)) return "Já existe uma conta com esse e-mail.";
    const novo = { ...dados, email };
    salvar(CHAVE_USUARIOS, [...usuarios, novo]);
    salvar(CHAVE_SESSAO, email);
    setUsuario(novo);
    return null;
  }

  function atualizar(dados: Partial<Usuario>) {
    if (!usuario) return;
    const atualizado = { ...usuario, ...dados, email: usuario.email };
    const usuarios = lerUsuarios().map((u) => (u.email === usuario.email ? atualizado : u));
    salvar(CHAVE_USUARIOS, usuarios);
    setUsuario(atualizado);
  }

  function sair() {
    remover(CHAVE_SESSAO);
    setUsuario(null);
  }

  return (
    <AuthContext.Provider value={{ usuario, entrar, cadastrar, atualizar, sair }}>{children}</AuthContext.Provider>
  );
}

export function useAuth() {
  const contexto = useContext(AuthContext);
  if (!contexto) throw new Error("useAuth precisa estar dentro do AuthProvider");
  return contexto;
}
