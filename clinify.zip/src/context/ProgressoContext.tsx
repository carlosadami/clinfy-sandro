// =========================================================
// Progresso do aluno: simulações feitas, desafios, flashcards
// e os indicadores do painel (sequência, nível, meta e acertos).
// Cada usuário tem o seu progresso salvo separadamente.
// =========================================================

import { createContext, useContext, useMemo, useState } from "react";
import type { ReactNode } from "react";
import { useAuth, USUARIO_TESTE } from "./AuthContext";
import { dataISO, diasAtras, ler, salvar } from "../lib/armazenamento";

export interface Resultado {
  casoId: string;
  nota: number;
  data: string; // ISO completa
  diagnosticoCorreto: boolean;
}

export interface Progresso {
  resultados: Resultado[];
  atividadesPorDia: Record<string, number>; // "2026-11-04": 3
  desafios: Record<string, boolean>; // dia -> acertou?
  flashcardsRevisados: number;
  metaDiaria: number;
}

const PROGRESSO_VAZIO: Progresso = {
  resultados: [],
  atividadesPorDia: {},
  desafios: {},
  flashcardsRevisados: 0,
  metaDiaria: 4,
};

/** Histórico de exemplo para o usuário de teste, para o painel não começar vazio. */
function progressoDemonstracao(): Progresso {
  const historico: [number, string, number, boolean][] = [
    [6, "pneumonia", 72, true],
    [5, "dor-toracica", 64, true],
    [4, "asma-pediatrica", 81, true],
    [3, "cetoacidose", 58, false],
    [2, "pneumonia", 90, true],
    [1, "dor-toracica", 85, true],
  ];
  const resultados = historico.map(([dias, casoId, nota, diagnosticoCorreto]) => ({
    casoId,
    nota,
    diagnosticoCorreto,
    data: diasAtras(dias).toISOString(),
  }));

  const atividadesPorDia: Record<string, number> = {};
  const desafios: Record<string, boolean> = {};
  for (let dias = 6; dias >= 1; dias--) {
    atividadesPorDia[dataISO(diasAtras(dias))] = 3;
    desafios[dataISO(diasAtras(dias))] = dias !== 3;
  }
  atividadesPorDia[dataISO()] = 2;

  return { resultados, atividadesPorDia, desafios, flashcardsRevisados: 34, metaDiaria: 4 };
}

function chaveDoUsuario(email: string) {
  return `clinify:progresso:${email}`;
}

function carregar(email: string): Progresso {
  const salvo = ler<Progresso | null>(chaveDoUsuario(email), null);
  if (salvo) return { ...PROGRESSO_VAZIO, ...salvo };
  return email === USUARIO_TESTE.email ? progressoDemonstracao() : PROGRESSO_VAZIO;
}

// ---------- cálculos dos indicadores ----------

function calcularSequencia(atividades: Record<string, number>) {
  let sequencia = 0;
  // se ainda não estudou hoje, a sequência continua contando a partir de ontem
  let dia = atividades[dataISO()] ? 0 : 1;
  while (atividades[dataISO(diasAtras(dia))]) {
    sequencia++;
    dia++;
  }
  return sequencia;
}

function media(valores: number[]) {
  return valores.length ? valores.reduce((soma, v) => soma + v, 0) / valores.length : 0;
}

export function calcularIndicadores(p: Progresso) {
  const xp =
    p.resultados.reduce((soma, r) => soma + r.nota, 0) +
    Object.values(p.desafios).filter(Boolean).length * 20 +
    p.flashcardsRevisados * 2;

  const seteDiasAtras = diasAtras(7).getTime();
  const notasSemana = p.resultados.filter((r) => new Date(r.data).getTime() >= seteDiasAtras).map((r) => r.nota);
  const notasAntes = p.resultados.filter((r) => new Date(r.data).getTime() < seteDiasAtras).map((r) => r.nota);

  const taxaAcerto = Math.round(media(p.resultados.map((r) => r.nota)));
  const variacaoSemana = notasAntes.length ? Math.round(media(notasSemana) - media(notasAntes)) : null;

  const atividadesHoje = p.atividadesPorDia[dataISO()] ?? 0;

  return {
    sequencia: calcularSequencia(p.atividadesPorDia),
    xp,
    nivel: Math.floor(xp / 100) + 1,
    progressoNivel: xp % 100,
    atividadesHoje,
    metaPercentual: Math.min(100, Math.round((atividadesHoje / p.metaDiaria) * 100)),
    taxaAcerto,
    variacaoSemana,
    totalSimulacoes: p.resultados.length,
  };
}

// ---------- contexto ----------

interface ProgressoContextTipo {
  progresso: Progresso;
  indicadores: ReturnType<typeof calcularIndicadores>;
  registrarResultado: (resultado: Omit<Resultado, "data">) => void;
  registrarDesafio: (acertou: boolean) => void;
  registrarFlashcard: () => void;
  alterarMeta: (meta: number) => void;
  resetarProgresso: () => void;
}

const ProgressoContext = createContext<ProgressoContextTipo | null>(null);

export function ProgressoProvider({ children }: { children: ReactNode }) {
  const { usuario } = useAuth();
  const email = usuario?.email ?? "";
  const [progresso, setProgresso] = useState<Progresso>(() => (email ? carregar(email) : PROGRESSO_VAZIO));
  const [emailCarregado, setEmailCarregado] = useState(email);

  // quando troca de usuário (login/logout), carrega o progresso dele
  if (emailCarregado !== email) {
    setEmailCarregado(email);
    setProgresso(email ? carregar(email) : PROGRESSO_VAZIO);
  }

  function atualizar(alterar: (anterior: Progresso) => Progresso) {
    setProgresso((anterior) => {
      const novo = alterar(anterior);
      if (email) salvar(chaveDoUsuario(email), novo);
      return novo;
    });
  }

  function somarAtividade(p: Progresso): Record<string, number> {
    const hoje = dataISO();
    return { ...p.atividadesPorDia, [hoje]: (p.atividadesPorDia[hoje] ?? 0) + 1 };
  }

  const valor: ProgressoContextTipo = {
    progresso,
    indicadores: useMemo(() => calcularIndicadores(progresso), [progresso]),
    registrarResultado: (resultado) =>
      atualizar((p) => ({
        ...p,
        resultados: [...p.resultados, { ...resultado, data: new Date().toISOString() }],
        atividadesPorDia: somarAtividade(p),
      })),
    registrarDesafio: (acertou) =>
      atualizar((p) => ({
        ...p,
        desafios: { ...p.desafios, [dataISO()]: acertou },
        atividadesPorDia: somarAtividade(p),
      })),
    registrarFlashcard: () =>
      atualizar((p) => ({
        ...p,
        flashcardsRevisados: p.flashcardsRevisados + 1,
        // a cada 5 flashcards conta como 1 atividade do dia
        atividadesPorDia: (p.flashcardsRevisados + 1) % 5 === 0 ? somarAtividade(p) : p.atividadesPorDia,
      })),
    alterarMeta: (meta) => atualizar((p) => ({ ...p, metaDiaria: meta })),
    resetarProgresso: () => atualizar(() => PROGRESSO_VAZIO),
  };

  return <ProgressoContext.Provider value={valor}>{children}</ProgressoContext.Provider>;
}

export function useProgresso() {
  const contexto = useContext(ProgressoContext);
  if (!contexto) throw new Error("useProgresso precisa estar dentro do ProgressoProvider");
  return contexto;
}
