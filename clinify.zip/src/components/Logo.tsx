import { useId } from "react";

interface LogoProps {
  tamanho?: number;
  comTexto?: boolean;
  claro?: boolean; // texto branco (para fundos escuros)
}

/** Logo do Clinify: um "C" com uma linha de batimento cardíaco. */
export function Logo({ tamanho = 36, comTexto = true, claro = false }: LogoProps) {
  // id único para o degradê (o logo aparece mais de uma vez na mesma tela)
  const idGradiente = useId();
  return (
    <span className="inline-flex items-center gap-2.5">
      <svg width={tamanho} height={tamanho} viewBox="0 0 64 64" aria-hidden="true">
        <defs>
          <linearGradient id={idGradiente} x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="#1d4f91" />
            <stop offset="1" stopColor="#7c4dcc" />
          </linearGradient>
        </defs>
        <rect width="64" height="64" rx="16" fill={`url(#${idGradiente})`} />
        <path d="M44 22a14 14 0 1 0 0 20" fill="none" stroke="#fff" strokeWidth="6" strokeLinecap="round" />
        <path d="M24 32h5l3-6 4 12 3-6h5" fill="none" stroke="#fff" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
      {comTexto && (
        <span className={`text-xl font-extrabold tracking-tight ${claro ? "text-white" : "text-marinho-700"}`}>
          CLINI<span className={claro ? "text-roxo-100" : "text-roxo-500"}>FY</span>
        </span>
      )}
    </span>
  );
}
