import type { LucideIcon } from "lucide-react";
import type { ReactNode } from "react";

interface Props {
  icone: LucideIcon;
  corIcone: string; // ex: "bg-orange-50 text-orange-500"
  valor: string;
  titulo: string;
  detalhe?: ReactNode;
}

/** Cartão pequeno com um número do painel (ex: 7 dias consecutivos). */
export function CartaoIndicador({ icone: Icone, corIcone, valor, titulo, detalhe }: Props) {
  return (
    <div className="cartao p-5 animate-aparecer">
      <div className={`mb-4 inline-flex size-9 items-center justify-center rounded-lg ${corIcone}`}>
        <Icone className="size-4.5" />
      </div>
      <p className="text-2xl font-bold text-slate-900">{valor}</p>
      <p className="text-sm text-slate-500">{titulo}</p>
      {detalhe && <div className="mt-2 text-xs">{detalhe}</div>}
    </div>
  );
}
