import type { Dificuldade } from "../data/casos";

const cores: Record<Dificuldade, string> = {
  Fácil: "bg-emerald-50 text-emerald-700 ring-emerald-200",
  Médio: "bg-amber-50 text-amber-700 ring-amber-200",
  Difícil: "bg-rose-50 text-rose-700 ring-rose-200",
};

export function SeloDificuldade({ dificuldade }: { dificuldade: Dificuldade }) {
  return (
    <span className={`rounded-full px-2.5 py-0.5 text-xs font-semibold ring-1 ${cores[dificuldade]}`}>{dificuldade}</span>
  );
}
